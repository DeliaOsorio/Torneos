using System;
using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
        //Una INTERFAZ especifica QUÉ SE DEBE HACER, pero NO CÓMO HACERLO
    public interface IREquipo
    {
            //Métodos solo firmados, es decir, indicamos QUÉ ES LO QUE TENEMOS QUE HACER, no cómo hacerlo
            
            //Método para listar los equipos, en una lista
        public IEnumerable<Equipo> ListarEquipos();

            //También podemos trabajar con una lista en vez de un IEnumerable, así:
        public List<Equipo> ListarEquipos1();
        
            //Operaciones CRUD:
        public bool CrearEquipo(Equipo equipo);
        
        public bool ActualizarEquipo(Equipo equipo);
        
        public bool EliminarEquipo(int id);
        
        public Equipo BuscarEquipo(int id);
    }
}