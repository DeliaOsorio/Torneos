using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia
{
        /* La clase REntrenador implementa al repositorio IREntrenador. 
           No es una Herencia, se llama IMPLEMENTAR, porque la herencia es entre clases
           y RMunicipio es una clase, pero IRMunicipio es una interfaz */

    public class REntrenador : IREntrenador
    {
            //Atributos
            /* Necesitamos la conexión a la BD, porque desde aquí se van a crear los metodos CRUD.
               Para ello debemos hacer uso de la cadena de conexión AppContext
               Creamos un obteto _appContext de tipo de dato AppContext*/
        private readonly AppContext _appContext;

            //Métodos

            //Constructor por defecto
        public REntrenador(AppContext appContext)
        {
            this._appContext = appContext;
        }

        public IEnumerable<Entrenador> ListarEntrenadores()
        {
                //Retorna todos los Entrenadores que estan en la BD
            return this._appContext.Entrenadores;
        }

        public List<Entrenador> ListarEntrenadores1()
        {
                //para que retorne una lista le ponemos .ToList()
            return this._appContext.Entrenadores.ToList();
        }

        public bool CrearEntrenador(Entrenador entrenador)
        {
            bool creado=false;
            try
            {
                this._appContext.Entrenadores.Add(entrenador);
                this._appContext.SaveChanges();
                creado=true;
            }
            catch (System.Exception)
            {
                creado=false;
            }
            return creado;
        }

        public bool ActualizarEntrenador(Entrenador entrenador)
        {
            bool actualizado=false;
                //Como vamos a buscar por un valor entero que es la PK utilizamos el método .Find()
            var ent = this._appContext.Entrenadores.Find(entrenador.Id);
            if(ent != null)
            {
                try
                {
                    ent.Documento = entrenador.Documento;
                    ent.Nombres = entrenador.Nombres;
                    ent.Apellidos = entrenador.Apellidos;
                    ent.Genero = entrenador.Genero;
                    ent.Deporte = entrenador.Deporte;
                    ent.RH = entrenador.RH;
                    ent.FechaNacimiento = entrenador.FechaNacimiento;
                    ent.Correo = entrenador.Correo;
                    ent.Celular = entrenador.Celular;
                    ent.EquipoId = entrenador.EquipoId;
                    this._appContext.SaveChanges();
                    actualizado=true;
                }
                catch (System.Exception)
                {
                    actualizado=false;
                }
            }
            return actualizado;
        }
        
        public bool EliminarEntrenador(int id)
        {
            bool eliminado=false;
            var ent = this._appContext.Entrenadores.Find(id);
            if(ent != null)
            {
                try
                {
                    this._appContext.Entrenadores.Remove(ent);
                    this._appContext.SaveChanges();
                    eliminado = true;
                }
                catch (System.Exception)
                {
                    eliminado = false;
                }                  
            }
            return eliminado;
        }
        
        public Entrenador BuscarEntrenador(int id)
        {
            return this._appContext.Entrenadores.Find(id);
        }
    }
}