using System;
using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
    public interface IRLogin
    {         
        public bool CrearLogin(Login login);
        
        public bool Validar(Login login);
    }
}