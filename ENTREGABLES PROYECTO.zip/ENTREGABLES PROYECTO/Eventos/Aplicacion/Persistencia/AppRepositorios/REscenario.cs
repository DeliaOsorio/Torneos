using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia
{
    public class REscenario : IREscenario
    {
        private readonly AppContext _appContex;

        //Metodos
        //Constructor
        public REscenario(AppContext appContext)
        {
            this._appContex = appContext;
        }

        public IEnumerable<Escenario> ListarEscenarios()
        {
            return this._appContex.Escenarios;
        }

        public List<Escenario> ListarEscenarios1()
        {
            return this._appContex.Escenarios.ToList();
        }

        public bool CrearEscenario(Escenario escenario)
        {
            bool creado = false;
            try
            {
                this._appContex.Escenarios.Add(escenario);
                this._appContex.SaveChanges();
                creado=true;
            }
            catch (System.Exception)
            {
                creado = false;
            }
            return creado;
        }

        public bool ActualizarEscenario(Escenario escenario)
        {
            bool actualizado= false;
            var esc = this._appContex.Escenarios.Find(escenario.Id);
            if(esc != null)
            {
                try
                {
                    esc.Nombre = escenario.Nombre;
                    esc.Direccion = escenario.Direccion;
                    esc.TorneoId = escenario.TorneoId;
                    this._appContex.SaveChanges();
                    actualizado = true;
                }
                catch (System.Exception)
                {
                    actualizado = false;
                }
            }
            return actualizado;
        }

        public bool EliminarEscenario(int id)
        {
            bool eliminado = false;
            var esc = this._appContex.Escenarios.Find(id);
            if(esc != null)
            {
                try
                {
                    this._appContex.Escenarios.Remove(esc);
                    this._appContex.SaveChanges();
                    eliminado = true;
                }
                catch (System.Exception)
                {
                    eliminado = false;
                }
            }
            return eliminado;
        }

        public Escenario BuscarEscenario(int id)
        {
            return this._appContex.Escenarios.Find(id);
        }
    }
}