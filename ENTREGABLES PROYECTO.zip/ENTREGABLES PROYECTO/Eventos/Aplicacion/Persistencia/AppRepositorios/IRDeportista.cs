using System;
using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
        //Una INTERFAZ especifica QUÉ SE DEBE HACER, pero NO CÓMO HACERLO
    
    public interface IRDeportista
    {
            //Método para listar los Deportistas, en una lista
        public IEnumerable<Deportista> ListarDeportistas();

        public List<Deportista> ListarDeportistas1();
       
            //Operaciones CRUD:
            
        public bool CrearDeportista(Deportista deportistas);
        
        public bool ActualizarDeportista(Deportista deportista);
        
        public bool EliminarDeportista(int id);
        
        public Deportista BuscarDeportista(int id);
    }
}