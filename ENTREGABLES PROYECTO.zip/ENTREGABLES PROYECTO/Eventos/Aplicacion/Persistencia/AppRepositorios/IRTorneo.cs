using System;
using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
        //Una INTERFAZ especifica QUÉ SE DEBE HACER, pero NO CÓMO HACERLO
    
    public interface IRTorneo
    {
            //Métodos solo firmados, es decir, indicamos QUÉ ES LO QUE TENEMOS QUE HACER, no cómo hacerlo

            //Método para listar los Torneos, en una lista
        public IEnumerable<Torneo> ListarTorneos();

        public List<Torneo> ListarTorneos1();
       
            //Operaciones CRUD:
            
        public bool CrearTorneo(Torneo torneos);
        
        public bool ActualizarTorneo(Torneo torneo);
        
        public bool EliminarTorneo(int id);
        
        public Torneo BuscarTorneo(int id);
    }
}