using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia 
{
    public class REspacio : IREspacio
    {
        private readonly AppContext _appContext;
        
        public REspacio(AppContext appContext)
        {
            this._appContext = appContext;
        }

        public IEnumerable<Espacio> ListarEspacios()
        {
            return this._appContext.Espacios;
        }

        public List<Espacio> ListarEspacios1()
        {
            return this._appContext.Espacios.ToList();
        }

        public bool CrearEspacio(Espacio espacio)
        {
            bool creado = false;
            try
            {
                this._appContext.Espacios.Add(espacio);
                this._appContext.SaveChanges();
                creado= true;
            }
            catch (System.Exception)
            {
                creado = false;
            }
            return creado;
        }

        public bool ActualizarEspacio(Espacio espacio)
        {
            bool actualizado = false;
            var esp = this._appContext.Espacios.Find(espacio.Id);
            if(esp != null)
            {
                try
                {
                   esp.Nombre = espacio.Nombre;
                   esp.Disciplina = espacio.Disciplina;
                   esp.Espectadores = espacio.Espectadores;
                   esp.EscenarioId = espacio.EscenarioId;
                   this._appContext.SaveChanges();
                   actualizado = true;
                }
                catch (System.Exception)
                {
                    actualizado = false;
                }   
            }    
            return actualizado;
        }

        public bool EliminarEspacio(int id)
        {
            bool eliminado = false;
            var esp = this._appContext.Espacios.Find(id);
            if(esp != null)
            {
                try
                {
                    this._appContext.Espacios.Remove(esp);
                    this._appContext.SaveChanges();
                    eliminado = true;
                }
                catch (System.Exception)
                {
                    eliminado = false;
                }
            }
            return eliminado;
        }

        public Espacio BuscarEspacio(int id)
        {
            return this._appContext.Espacios.Find(id);
        }
    }
}