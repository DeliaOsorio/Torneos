using System;
using System.Collections.Generic;
using Dominio;

namespace Persistencia
{    
    public interface IRTorneoEquipo
    {
            //Método para listar los TorneoEquipos, en una lista
        public IEnumerable<TorneoEquipo> ListarTorneoEquipos();
       
            //Operaciones CRUD:
            
        public bool CrearTorneoEquipo(TorneoEquipo obj);
              
        public bool EliminarTorneoEquipo(int idT, int IdE); //Como es una llave compuesta, para eliminar debe recibir las dos llaves
        
        public TorneoEquipo BuscarTorneoEquipo(int idT, int IdE); //Como es una llave compuesta, para buscar debe recibir las dos llaves
    }
}