using System;
using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
        //Una INTERFAZ especifica QUÉ SE DEBE HACER, pero NO CÓMO HACERLO
    
    public interface IRPatrocinador
    {
            //Métodos solo firmados, es decir, indicamos QUÉ ES LO QUE TENEMOS QUE HACER, no cómo hacerlo

            //Método para listar los Patrocinadores, en una lista
        public IEnumerable<Patrocinador> ListarPatrocinadores();

        public List<Patrocinador> ListarPatrocinadores1();
       
            //Operaciones CRUD:

        public bool CrearPatrocinador(Patrocinador patrocinador);
        
        public bool ActualizarPatrocinador(Patrocinador patrocinador);
        
        public bool EliminarPatrocinador(int id);
        
        public Patrocinador BuscarPatrocinador(int id);
    }
}