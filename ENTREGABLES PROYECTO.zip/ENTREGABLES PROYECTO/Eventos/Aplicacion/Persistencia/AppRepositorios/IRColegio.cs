using System;
using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
        //Una INTERFAZ especifica QUÉ SE DEBE HACER, pero NO CÓMO HACERLO
    
    public interface IRColegio
    {
            //Métodos solo firmados, es decir, indicamos QUÉ ES LO QUE TENEMOS QUE HACER, no cómo hacerlo

            //Método para listar los Colegios, en una lista
        public IEnumerable<Colegio> ListarColegios();

        public List<Colegio> ListarColegios1();
       
            //Operaciones CRUD:

        public bool CrearColegio(Colegio colegio);
        
        public bool ActualizarColegio(Colegio colegio);
        
        public bool EliminarColegio(int id);
        
        public Colegio BuscarColegio(int id);
    }
}