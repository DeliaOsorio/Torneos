using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia
{
    public class RDeportista : IRDeportista                     // La clase RDeportista implementa al repositorio IRDeportista 
    {
            //Atributos
            //Necesitamos la conexión a la BD, porque desde aquí se van a crear los metodos CRUD, hacemos uso de la cadena de conexión AppContext  
        private readonly AppContext _appContext;                //Creamos un obteto _appContext de tipo de dato AppContext

            //......................Métodos.....................

            //Constructor por defecto
        public RDeportista(AppContext appContext)
        {
            this._appContext = appContext;
        }
            //..................................................

        public IEnumerable<Deportista> ListarDeportistas()
        {
            return this._appContext.Deportistas;                    //Retorna todos los deportistas que estan en la BD
        }
            //..................................................

        public List<Deportista> ListarDeportistas1()
        {
            return this._appContext.Deportistas.ToList();           //Para que retorne una lista le ponemos .ToList()
        }
            //..................................................

        public bool CrearDeportista(Deportista deportista)
        {
            bool creado=false;
                try                                                 //Si no existe, intente adicionar ese deportista
                {
                    this._appContext.Deportistas.Add(deportista);
                    this._appContext.SaveChanges();                 
                    creado=true;
                }
                catch (System.Exception)
                {
                    creado=false;
                }
            return creado;
        }
            //..................................................

        public bool ActualizarDeportista(Deportista deportista)
        {
            bool actualizado=false;                                         //Como vamos a buscar por un valor entero que es la PK utilizamos el método .Find()
            var dep = this._appContext.Deportistas.Find(deportista.Id);     //Utilizamos un objeto temporal que vamos a llamar dep que va a tener los datos del registro de la BD
            if(dep != null)
            {
                try
                {
                    dep.Documento = deportista.Documento;
                    dep.Nombres = deportista.Nombres;
                    dep.Apellidos = deportista.Apellidos;
                    dep.Deporte = deportista.Deporte;
                    dep.RH = deportista.RH;
                    dep.FechaNacimiento = deportista.FechaNacimiento;
                    dep.Genero = deportista.Genero;
                    dep.Correo = deportista.Correo;
                    dep.Celular = deportista.Celular;
                    dep.EquipoId = deportista.EquipoId;

                    this._appContext.SaveChanges();
                    actualizado = true;
                }
                catch (System.Exception)
                {
                    actualizado = false;
                }
            }
            return actualizado;
        }
            //..................................................

        public bool EliminarDeportista(int id)
        {
            bool eliminado=false;
            var dep= this._appContext.Deportistas.Find(id);
            if(dep != null)
            {
                try
                {
                    this._appContext.Deportistas.Remove(dep);
                    this._appContext.SaveChanges();
                    eliminado=true;
                }
                catch (System.Exception)
                {
                   eliminado=false;
                }  
            }
            return eliminado;
        }
                // NOTA: Por cada Equipo pueden existir muchos deportistas "e.Deportistas" y cada Deportista pertenece a un solo equipo "d.Equipo" 
                //       En AppContext se controla la eliminación en casacada desde Equipo. Es decir, al eliminar un equipo no se eliminan los deportistas.
            
            //..................................................

        public Deportista BuscarDeportista(int id)
        {
            return this._appContext.Deportistas.Find(id);
        }
    }
}