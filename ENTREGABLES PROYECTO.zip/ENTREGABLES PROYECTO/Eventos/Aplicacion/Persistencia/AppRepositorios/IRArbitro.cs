using System;
using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
        //Una INTERFAZ especifica QUÉ SE DEBE HACER, pero NO CÓMO HACERLO

    public interface IRArbitro
    {
            //Métodos solo firmados, es decir, indicamos QUÉ ES LO QUE TENEMOS QUE HACER, no cómo hacerlo
            
            //Método para listar los Arbitros, en una lista
        public IEnumerable<Arbitro> ListarArbitros();

            //También podemos trabajar con una lista en vez de un IEnumerable, así:
        public List<Arbitro> ListarArbitros1();
        
            //Operaciones CRUD:
        public bool CrearArbitro(Arbitro arbitro);
        
        public bool ActualizarArbitro(Arbitro arbitro);
        
        public bool EliminarArbitro(int id);
        
        public Arbitro BuscarArbitro(int id);
    }
}