using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia
{
        /* La clase RMunicipio implementa al repositorio IRMunicipio. 
           No es una Herencia, se llama IMPLEMENTAR, porque la herencia es entre clases
           y RMunicipio es una clase, pero IRMunicipio es una interfaz */

    public class RMunicipio: IRMunicipio
    {
        //Atributos
        //Necesitamos la conexión a la BD, porque desde aquí se van a crear los metodos CRUD.
        //Para ello debemos hacer uso de la cadena de conexión AppContext
        
        //Creamos un obteto _appContext de tipo de dato AppContext
        private readonly AppContext _appContext;

        //Métodos

        //Constructor por defecto
        public RMunicipio(AppContext appContext)
        {
            this._appContext = appContext;
        }

        public IEnumerable<Municipio> ListarMunicipios()
        {
            //Retorna todos los municipios que estan en la BD
            return this._appContext.Municipios;
        }
        public List<Municipio> ListarMunicipios1()
        {
            //para que retorne una lista le ponemos .ToList()
            return this._appContext.Municipios.ToList();
        }

        public bool CrearMunicipio(Municipio municipio)
        {
            bool creado=false;
            bool ex = Existe(municipio);
            if(!ex)
            {
                try
                {
                    this._appContext.Municipios.Add(municipio);
                    //Es obligatorio hacer un guardado de cambios para que la BD se actualice con SaveChanges()
                    this._appContext.SaveChanges();
                    creado=true;
                }
                catch (System.Exception)
                {
                    creado=false;
                }
            }

            return creado;
        }

        public bool ActualizarMunicipio(Municipio municipio)
        {
            bool actualizado=false;
            //Como vamos a buscar por un valor entero que es la llave primaria utilizamos el método .Find()
            var mun = this._appContext.Municipios.Find(municipio.Id);
            if(mun != null)
            {
                bool ex = Existe(municipio);
                if(!ex)
                {
                    try
                    {
                        mun.Nombre = municipio.Nombre;
                        this._appContext.SaveChanges();
                        actualizado=true;
                    }
                    catch (System.Exception)
                    {
                        actualizado=false;
                    }
                }
            }
            return actualizado;
        }
        
        public bool EliminarMunicipio(int idMunicipio)
        {
            bool eliminado=false;
            var mun= this._appContext.Municipios.Find(idMunicipio);
            if(mun != null)
            {
                    //Para evitar borrar en cascada, es decir, para evitar borrar torneos que tengan el municipio se debe validar, así
                    //Buscamos en Torneos el Id del Municipio y con un solo registro que tenga el municipio NO se puede borrar
                var torneo = _appContext.Torneos.FirstOrDefault(t=> t.MunicipioId == mun.Id);
                if(torneo == null)  //Si no encuentra ningún Torneo con ese municipio, se puede borrar
                {
                    try
                    {
                        this._appContext.Municipios.Remove(mun);
                        this._appContext.SaveChanges();
                        eliminado=true;
                    }
                    catch (System.Exception)
                    {
                    eliminado=false;
                    }  
                }                
            }
            return eliminado;
        }
        
        public Municipio BuscarMunicipio(int idMunicipio)
        {
            Municipio municipio= this._appContext.Municipios.Find(idMunicipio);
            return municipio;
        }

        //Creamos un método para validar el Nombre del municipio, para que no se repita. Lo va a utilizar
        //internamente esta clase, por eso lo declaramos private, y no lo firmamos en IRMunicipio
        private bool Existe(Municipio muni)
        {
            bool ex = false;
            var mun = _appContext.Municipios.FirstOrDefault(m => m.Nombre == muni.Nombre); //Haga la busqueda con el parámetro muni.Nombre y cuando encuentre el primero, que se detenga
            if(mun != null)
            {
                ex = true;
            }
            return ex;
        }

    }
}