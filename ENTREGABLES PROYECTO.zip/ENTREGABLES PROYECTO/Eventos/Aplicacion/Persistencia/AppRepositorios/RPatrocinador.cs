using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia
{
        /* La clase RPatrocinador implementa al repositorio IRPatrocinador. 
           No es una Herencia, se llama IMPLEMENTAR, porque la herencia es entre clases
           y RPatrocinador es una clase, pero IRPatrocinador es una interfaz */
           
    public class RPatrocinador: IRPatrocinador
    {
            //Atributos
            //Necesitamos la conexión a la BD, porque desde aquí se van a crear los metodos CRUD.
            //Para ello debemos hacer uso de la cadena de conexión AppContext
        
            //Creamos un obteto _appContext de tipo de dato AppContext
        private readonly AppContext _appContext;

            //Métodos

            //Constructor por defecto
        public RPatrocinador(AppContext appContext)
        {
            this._appContext = appContext;
        }

        public IEnumerable<Patrocinador> ListarPatrocinadores()
        {
                //Retorna todos los patrocinadores que estan en la BD
            return this._appContext.Patrocinadores;
        }
        public List<Patrocinador> ListarPatrocinadores1()
        {
                //para que retorne una lista le ponemos .ToList()
            return this._appContext.Patrocinadores.ToList();
        }
        public bool CrearPatrocinador(Patrocinador patrocinador)
        {
            bool creado=false;
            //bool ex = Existe(patrocinador);
            //if(!ex)
            //{
                try   //Si no existe intente adicionar ese patrocinador
                {
                    this._appContext.Patrocinadores.Add(patrocinador);
                    //Es obligatorio hacer un guardado de cambios para que la BD se actualice con SaveChanges()
                    this._appContext.SaveChanges();
                    creado=true;
                }
                catch (System.Exception)
                {
                    creado=false;
                }
            //}
            return creado;
        }

        public bool ActualizarPatrocinador(Patrocinador patrocinador)
        {
            bool actualizado=false;
                //Como vamos a buscar por un valor entero que es la llave primaria utilizamos el método .Find()
                //Utilizamos un objeto temporal que vamos a llamar pat que va a tener los datos del registro de la BD
            var pat = this._appContext.Patrocinadores.Find(patrocinador.Id);
            if(pat != null)
            {
                //bool ex = Existe(patrocinador);
                //if(!ex)
                //{
                    try
                    {
                        pat.Nombre = patrocinador.Nombre;
                        pat.Documento = patrocinador.Documento;
                        pat.TipoPersona = patrocinador.TipoPersona;
                        pat.Direccion =patrocinador.Direccion;
                        pat.Telefono = patrocinador.Telefono;
                        this._appContext.SaveChanges();
                        actualizado = true;
                    }
                    catch (System.Exception)
                    {
                        actualizado = false;
                    }
                //}
            }
            return actualizado;
        }

        public bool EliminarPatrocinador(int id)
        {
            bool eliminado=false;
            var pat= this._appContext.Patrocinadores.Find(id);
            if(pat != null)
            {
                try
                {
                    this._appContext.Patrocinadores.Remove(pat);
                    this._appContext.SaveChanges();
                    eliminado=true;
                }
                catch (System.Exception)
                {
                   eliminado=false;
                }  
            }
            return eliminado;
        }
        
        public Patrocinador BuscarPatrocinador(int id)
        {
            Patrocinador patrocinador= this._appContext.Patrocinadores.Find(id);
            return patrocinador;
        }

            /*Se creó un método para validar el Nombre del patrocinador, para que no se repita. Lo va a utilizar
              internamente esta clase, por eso lo declaramos private, y no lo firmamos en IRPatrocinador.
              Solo lo usa el método CrearPatrocinador, pero ya no vamos a utilizar este metodo Existe porque crear
              esta utilizando un Unique y ya no la función Existe
              */
        private bool Existe(Patrocinador patrocinador)
        {
            bool ex = false;
            var pat = _appContext.Patrocinadores.FirstOrDefault(p => p.Documento == patrocinador.Documento); //Funciona como un Foreach. Hace la busqueda con el parámetro patrocinador.Documento y cuando encuentra el primero se detiene
            if(pat != null)
            {
                ex = true;
            }
            return ex;
        }

    }
}