using System;
using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
    public interface IREscenario
    {
        public IEnumerable<Escenario> ListarEscenarios();
        public List<Escenario> ListarEscenarios1();
        public bool CrearEscenario(Escenario escenario);
        public bool ActualizarEscenario(Escenario escenario);
        public bool EliminarEscenario(int id);
        public Escenario BuscarEscenario(int id);
    }
}