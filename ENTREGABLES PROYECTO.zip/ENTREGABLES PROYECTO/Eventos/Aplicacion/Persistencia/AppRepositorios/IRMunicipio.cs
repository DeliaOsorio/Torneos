using System;
using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
            //Una INTERFAZ especifica QUÉ SE DEBE HACER, pero NO CÓMO HACERLO
    public interface IRMunicipio
    {
            //Métodos solo firmados, es decir, indicamos QUÉ ES LO QUE TENEMOS QUE HACER, no cómo hacerlo

            //Método para listar los municipios, en una lista
        public IEnumerable<Municipio> ListarMunicipios();
        
            //También podemos trabajar con una lista en vez de un IEnumerable, así:
        public List<Municipio> ListarMunicipios1();
        
            //Operaciones CRUD:

        public bool CrearMunicipio(Municipio municipio);
        
        public bool ActualizarMunicipio(Municipio municipio);
        
        public bool EliminarMunicipio(int idMunicipio);
        
        public Municipio BuscarMunicipio(int idMunicipio);
    }
}