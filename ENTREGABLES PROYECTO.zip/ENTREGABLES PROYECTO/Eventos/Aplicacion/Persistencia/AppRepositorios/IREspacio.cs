using System;
using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
    public interface IREspacio
    {
    public IEnumerable<Espacio> ListarEspacios();
     public List<Espacio> ListarEspacios1();
     public bool CrearEspacio(Espacio espacio);
     public bool ActualizarEspacio(Espacio espacio);
     public bool EliminarEspacio(int id);
     public Espacio BuscarEspacio(int id);
    }    
}