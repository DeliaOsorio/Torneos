using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia
{
        /* La clase RColegio implementa al repositorio IRColegio. 
           No es una Herencia, se llama IMPLEMENTAR, porque la herencia es entre clases
           y RColegio es una clase, pero IRColegio es una interfaz */
           
    public class RColegio: IRColegio
    {
            /*Atributos
              Necesitamos la conexión a la BD, porque desde aquí se van a crear los metodos CRUD.
              Hacemos uso de la cadena de conexión AppContext */

        private readonly AppContext _appContext;                //Creamos un obteto llamado _appContext de tipo de dato AppContext

            //......................Métodos.....................
        
        public RColegio(AppContext appContext)                  //Constructor por defecto
        {
            this._appContext = appContext;
        }
            //..................................................
        
        public IEnumerable<Colegio> ListarColegios()            //Retorna todos los colegios que estan en la BD
        {
            return this._appContext.Colegios;
        }
            //..................................................
        
        public List<Colegio> ListarColegios1()                  //Para que retorne una lista le ponemos .ToList()
        {
            return this._appContext.Colegios.ToList();
        }
            //...................................................
       
        public bool CrearColegio(Colegio colegio)
        {
            bool creado = false;
            //bool ex = Existe(colegio);
            //if(!ex)
            //{
                try   //Si no existe intente adicionar ese patrocinador
                {
                    this._appContext.Colegios.Add(colegio);       
                    this._appContext.SaveChanges();             //Es obligatorio hacer un guardado de cambios con SaveChanges() para que la BD se actualice
                    creado=true;
                }
                catch (System.Exception)
                {
                    creado=false;
                }
            //}
            return creado;
        }
            //...................................................

        public bool ActualizarColegio(Colegio colegio)
        {                                                          
            bool actualizado = false;                                                                                               
            var col = this._appContext.Colegios.Find(colegio.Id);   //Como vamos a buscar por la PK que es un valor entero usamos el método .Find()
            if(col != null)                                         //Usamos un objeto temporal que vamos a llamar col que va a tener los datos del registro de la BD 
            {
                    try
                    {
                        col.Nit = colegio.Nit;
                        col.RazonSocial = colegio.RazonSocial;
                        col.Direccion = colegio.Direccion;
                        col.Correo = colegio.Correo;

                        this._appContext.SaveChanges();
                        actualizado = true;
                    }
                    catch (System.Exception)
                    {
                        actualizado = false;
                    }
            }
            return actualizado;
        }
            //...................................................

        public bool EliminarColegio(int id)
        {
            bool eliminado = false;
            var col = this._appContext.Colegios.Find(id);       //Como vamos a buscar por la PK que es un valor entero usamos el método .Find()
            if(col != null)                                     //Usamos un objeto temporal que vamos a llamar col que va a tener los datos del registro de la BD 
            {
                try
                {
                    this._appContext.Colegios.Remove(col);
                    this._appContext.SaveChanges();
                    eliminado=true;
                }
                catch (System.Exception)
                {
                   eliminado=false;
                }  
            }
            return eliminado;
        }
            //...................................................

        public Colegio BuscarColegio(int id)
        {
            Colegio colegio = this._appContext.Colegios.Find(id);
            return colegio;
        }
            //...................................................

            /*Se creó un método para validar el Nombre del colegio, para que no se repita. Lo va a utilizar
              internamente esta clase, por eso lo declaramos private, y no lo firmamos en IRColegio.
              Solo lo usa el método CrearColegio, pero ya no vamos a utilizar este metodo Existe porque la
              función CrearColegio() esta utilizando un IsUnique definido en AppContext y ya no la función Existe */

        /*private bool Existe(Colegio colegio)
        {
            bool ex = false;
            var col = _appContext.Colegios.FirstOrDefault(c => c.Nit == colegio.Nit);   //Funciona como un Foreach. 
            if(col != null)                                                            //Hace la busqueda con el parámetro colegio.Nit y cuando encuentra el primero se detiene
            {
                ex = true;
            }
            return ex;
        }*/
    }
}