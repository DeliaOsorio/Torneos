using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia
{
        /* La clase REquipo implementa al repositorio IREquipo. 
           No es una Herencia, se llama IMPLEMENTAR, porque la herencia es entre clases
           y REquipo es una clase, pero IREquipo es una interfaz */

    public class REquipo : IREquipo
    {
            //Atributos
            //Necesitamos la conexión a la BD, porque desde aquí se van a crear los metodos CRUD.
            //Para ello debemos hacer uso de la cadena de conexión AppContext
        
            //Creamos un objeto _appContext de tipo de dato AppContext
        private readonly AppContext _appContext;

            //Métodos
            //Constructor
        public REquipo(AppContext appContext)
        {
            this._appContext = appContext;
        }

        public IEnumerable<Equipo> ListarEquipos()
        {
                //Retorna todos los equipos que estan en la BD
            return this._appContext.Equipos;
        }

        public List<Equipo> ListarEquipos1()
        {
                //para que retorne una lista le ponemos .ToList()
            return this._appContext.Equipos.ToList();
        }

        public bool CrearEquipo(Equipo equipo)
        {
                //Vamos a validar con Unique, no con el método Existe. Para eso debemos ir a AppContext y hacer la asignación IsUnique() a Nombre
            bool creado=false;
            try
            {
                this._appContext.Equipos.Add(equipo);
                this._appContext.SaveChanges();
                creado=true;
            }
            catch (System.Exception)
            {
                creado=false;
            }
            return creado;
        }

        public bool ActualizarEquipo(Equipo equipo)
        {
            bool actualizado=false;
                //Como vamos a buscar por un valor entero que es el Id, utilizamos el método .Find()
                //Utilizamos un objeto temporal que vamos a llamar equ que va a tener los datos del registro de la BD
            var equ = this._appContext.Equipos.Find(equipo.Id);
            if(equ != null)
            {
                try
                {
                    equ.Nombre = equipo.Nombre;
                    equ.Deporte = equipo.Deporte;
                    equ.PatrocinadorId = equipo.PatrocinadorId;
                    this._appContext.SaveChanges();
                    actualizado=true;
                }
                catch (System.Exception)
                {
                    actualizado=false;
                }
            }   
            return actualizado;
        }         
        
        public bool EliminarEquipo(int idEquipo)
        {
            bool eliminado=false;
            var equ = this._appContext.Equipos.Find(idEquipo);
            if(equ != null)
            {
                /*  //Para evitar borrar en cascada, es decir, para evitar borrar torneos que tengan el municipio se debe validar, así
                    //Buscamos en Torneos el Id del Municipio y con un solo registro que tenga el municipio NO se puede borrar
                var entrenador = _appContext.Entrenadores.FirstOrDefault(t => t.EquipoId == equ.Id);
                if(entrenador == null)  //Si no encuentra ningún Torneo con ese municipio, se puede borrar
                {
                */
                    try
                    {
                        this._appContext.Equipos.Remove(equ);
                        this._appContext.SaveChanges();
                        eliminado=true;
                    }
                    catch (System.Exception)
                    {
                        eliminado=false;
                    }  
                //}                
            }
            return eliminado;
        }
        
        public Equipo BuscarEquipo(int idEquipo)
        {
            return this._appContext.Equipos.Find(idEquipo);
        }
    }
}