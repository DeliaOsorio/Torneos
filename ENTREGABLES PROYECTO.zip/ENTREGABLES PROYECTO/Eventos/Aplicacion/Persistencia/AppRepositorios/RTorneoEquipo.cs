using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia
{
    public class RTorneoEquipo : IRTorneoEquipo
    {
            //Atributos
            //Necesitamos la conexión a la BD, porque desde aquí se van a crear los metodos CRUD.
            //Para ello debemos hacer uso de la cadena de conexión AppContext
        
            //Creamos un obteto _appContext de tipo de dato AppContext
        private readonly AppContext _appContext;

            //Métodos
            //Constructor por defecto
        public RTorneoEquipo(AppContext appContext)
        {
            this._appContext = appContext;
        }

        public IEnumerable<TorneoEquipo> ListarTorneoEquipos()
        {
                //Retorna todos los torneoEquipos que estan en la BD
            return this._appContext.TorneoEquipos;
        }
        
        public bool CrearTorneoEquipo(TorneoEquipo obj)
        {
            bool creado = false;
            bool ex = Validar(obj);
            if(!ex)
            {
                try     //Si no existe, intente adicionar ese torneoequipo
                {
                    this._appContext.TorneoEquipos.Add(obj);
                    this._appContext.SaveChanges();     //Es obligatorio hacer un guardado de cambios para que la BD se actualice con SaveChanges()
                    creado=true;
                }
                catch (System.Exception)
                {
                    creado=false;
                }
            }
            return creado;
        }

        public bool EliminarTorneoEquipo(int idT, int idE)
        {
            bool eliminado=false;
            var torequ= this._appContext.TorneoEquipos.FirstOrDefault(t => t.TorneoId == idT    //El FirstOrDefault funciona como un foreach   
                                                                        && t.EquipoId == idE);
            if(torequ != null)
            {
                try
                {
                    this._appContext.TorneoEquipos.Remove(torequ);
                    this._appContext.SaveChanges();
                    eliminado=true;
                }
                catch (System.Exception)
                {
                   eliminado=false;
                }  
            }
            return eliminado;
        }
        
        public TorneoEquipo BuscarTorneoEquipo(int idT, int idE)
        {
            return this._appContext.TorneoEquipos.FirstOrDefault(t => t.TorneoId == idT   //El FirstOrDefault funciona como un foreach
                                                                   && t.EquipoId == idE); //cuando buscamos por PK utilizamos el Find(). cuano es llave compuesta buscamos con FirstOrDefault
        }

        private bool Validar(TorneoEquipo obj)
        {
            bool existe = false;
            var torequ = _appContext.TorneoEquipos.FirstOrDefault(t => t.EquipoId == obj.EquipoId //El FirstOrDefault funciona como un foreach
                                                                   && t.TorneoId == obj.TorneoId);
            if(torequ != null)
            {
                existe = true;
            }
            return existe;
        }
    }
}