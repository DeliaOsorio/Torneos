using Microsoft.EntityFrameworkCore;
using Dominio;

namespace Persistencia
{
    //creamos una clase la cual hereda de la superclase DbContext
    public class AppContext:DbContext
    {
        //Atributos, con un tipo de dato especial llamada DbSet, que va a representar una clase existente en el Dominio, es decir, si en
        //el Dominio tenemos 3 clases, debemos crear 3 atributos DbSet con el nombre el plural con su get y set
        public DbSet<Municipio> Municipios {get;set;}
        public DbSet<Patrocinador> Patrocinadores {get;set;}
        public DbSet<Colegio> Colegios {get;set;}
        public DbSet<Torneo> Torneos {get;set;}
        public DbSet<Deportista> Deportistas {get;set;}
        public DbSet<Escenario> Escenarios {get;set;}
        public DbSet<Espacio> Espacios {get;set;}
        public DbSet<Arbitro> Arbitros {get;set;}
        public DbSet<Entrenador> Entrenadores {get;set;}
        public DbSet<Equipo> Equipos {get;set;}
        public DbSet<TorneoEquipo> TorneoEquipos {get;set;}
        public DbSet<Login> Logins {get;set;}

        //Crear la conexion con la BD. utilizamos un metodo que ya existe y hacemos una modificación a manero de metodo sobreescrito.
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if(!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB; Initial Catalog=Eventos29");
            }
        
        }

        /*
        Vamos a crear la llave compuesta de TorneoEquipo, sobreescribiendo el método OnModelCreating:
        Este método se dispara al momento de generar las migraciones y a partir de esas migraciones crear los modelos.
        Recibe un objeto de tipo ModelBuilder
        Le indicamos que vamos a configurar una entidad, para eso utilizamos el método Entity y le decimos cuál es la entidad que
        necesitamos configurar, en este caso es TorneoEquipo, y utilizamos un método llamado HasKey (asignar clave) y le indicamos 
        la llave compuesta: EquipoId y TorneoID
        */
            //API fluente
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
                //Crear una llave primaria compuesta de TorneoEquipo

            modelBuilder.Entity<TorneoEquipo>().HasKey(x=>new{x.TorneoId,x.EquipoId}); //Si arroja error, invertir el orden de los campos

                // Asignar un Index único. Reemplaza la validación con el método creado Exite()
                // para controlar que no se creen entidades con Nombres, Documentos, Nit o Usuario repetidos.

            modelBuilder.Entity<Patrocinador>().HasIndex(p => p.Documento).IsUnique();  
            modelBuilder.Entity<Torneo>().HasIndex(t => t.Nombre).IsUnique();      
            modelBuilder.Entity<Equipo>().HasIndex(e => e.Nombre).IsUnique(); 
            modelBuilder.Entity<Entrenador>().HasIndex(ent => ent.Documento).IsUnique();
            modelBuilder.Entity<Login>().HasIndex(l => l.Usuario).IsUnique(); 
            modelBuilder.Entity<Colegio>().HasIndex(c => c.Nit).IsUnique(); 
            modelBuilder.Entity<Arbitro>().HasIndex(a => a.Documento).IsUnique(); 
            modelBuilder.Entity<Deportista>().HasIndex(a => a.Documento).IsUnique();
            modelBuilder.Entity<Escenario>().HasIndex(esc => esc.Nombre).IsUnique();
            modelBuilder.Entity<Espacio>().HasIndex(esp => esp.Nombre).IsUnique();
                
                //.....................CONTROLAR ELIMINACIÓN EN CASCADA ......................

                // Controlar la eliminación en cascada (Al borrar un Patrocinador, NO permitir borrar los equipos que esten relacionados con ese Patrocinador). 
                 
            modelBuilder.Entity<Patrocinador>()
                                  .HasMany(p => p.Equipos)              // Por cada patrocinador pueden existir muchos equipos "p.equipos"
                                  .WithOne(e => e.Patrocinador)         // y por cada equipo tenemos un solo patrocinador "e.Patrocinador"
                                  .OnDelete(DeleteBehavior.Restrict);

                //.................................................................................
                
                // Controlar la eliminación en cascada (Al borrar un Colegio, NO permitir borrar los Árbitros que estén relacionados con ese colegio).  
 
            modelBuilder.Entity<Colegio>()
                                  .HasMany(c => c.Arbitros)             // Por cada Colegio pueden existir muchos Árbitros "c.Arbitros"
                                  .WithOne(a => a.Colegio)              // y por cada Árbitro tenemos un solo colegio "a.Colegio"
                                  .OnDelete(DeleteBehavior.Restrict);

                //...................................................................................
                
                // Controlar la eliminación en cascada (Al borrar un Equipo, NO permitir borrar los Deportistas que esten relacionados on ese Equipo). 
                // Si el EQUIPO se elimina, se elimina también el ENTRENADOR, pero, si el EQUIPO tiene DEPORTISTAS no se permite eliminar el EQUIPO
                 
            modelBuilder.Entity<Equipo>()
                                  .HasMany(e => e.Deportistas)          // Por cada Equipo pueden existir muchos Deportistas "e.Deportistas"
                                  .WithOne(d => d.Equipo)               // y por cada Deportista pertenece a un solo equipo "d.Equipo"
                                  .OnDelete(DeleteBehavior.Restrict);
         
            // Necesitaba definir un valor por defecto  de cero a CantEquipos 
            // modelBuilder.Entity<Torneo>().Property(t => t.CantEquipos).HasDefaultValue(0);
        }
    }
}