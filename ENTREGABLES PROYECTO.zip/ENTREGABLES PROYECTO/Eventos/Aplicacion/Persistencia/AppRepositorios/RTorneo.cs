using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia
{
        /* La clase RTorneo implementa al repositorio IRTorneo. 
           No es una Herencia, se llama IMPLEMENTAR, porque la herencia es entre clases
           y RTorneo es una clase, pero IRTorneo es una interfaz */

    public class RTorneo : IRTorneo
    {
            //Atributos
            //Necesitamos la conexión a la BD, porque desde aquí se van a crear los metodos CRUD.
            //Para ello debemos hacer uso de la cadena de conexión AppContext
        
            //Creamos un obteto _appContext de tipo de dato AppContext
        private readonly AppContext _appContext;

            //Métodos

            //Constructor por defecto
        public RTorneo(AppContext appContext)
        {
            this._appContext = appContext;
        }

        public IEnumerable<Torneo> ListarTorneos()
        {
                //Retorna todos los torneos que estan en la BD
            return this._appContext.Torneos;
        }
        public List<Torneo> ListarTorneos1()
        {
                //para que retorne una lista le ponemos .ToList()
            return this._appContext.Torneos.ToList();
        }
        
        public bool CrearTorneo(Torneo torneo)
        {
            bool creado=false;
            //torneo.CantEquipos = 0;
            //bool ex = Existe(torneo);
            //if(!ex)
            //{
                try     //Si no existe, intente adicionar ese torneo
                {
                    this._appContext.Torneos.Add(torneo);
                    this._appContext.SaveChanges();     //Es obligatorio hacer un guardado de cambios para que la BD se actualice con SaveChanges()
                    creado=true;
                }
                catch (System.Exception)
                {
                    creado=false;
                }
            //}
            return creado;
        }

        public bool ActualizarTorneo(Torneo torneo)
        {
            bool actualizado=false;
                //Como vamos a buscar por un valor entero que es la llave primaria utilizamos el método .Find()
                //Utilizamos un objeto temporal que vamos a llamar tor que va a tener los datos del registro de la BD
            var tor = this._appContext.Torneos.Find(torneo.Id);
            if(tor != null)
            {
                try
                {
                    tor.Nombre = torneo.Nombre;
                    tor.Categoria = torneo.Categoria;
                    tor.Deporte = torneo.Deporte;
                    tor.FechaInicial = torneo.FechaInicial;
                    tor.FechaFinal = torneo.FechaFinal;
                    tor.CantEquipos = torneo.CantEquipos;
                    tor.MunicipioId = torneo.MunicipioId;
                    this._appContext.SaveChanges();
                    actualizado = true;
                }
                catch (System.Exception)
                {
                    actualizado = false;
                }
            }
            return actualizado;
        }

        public bool EliminarTorneo(int id)
        {
            bool eliminado=false;
            var tor= this._appContext.Torneos.Find(id);
            if(tor != null)
            {
                try
                {
                    this._appContext.Torneos.Remove(tor);
                    this._appContext.SaveChanges();
                    eliminado=true;
                }
                catch (System.Exception)
                {
                   eliminado=false;
                }  
            }
            return eliminado;
        }
        
        public Torneo BuscarTorneo(int id)
        {
            return this._appContext.Torneos.Find(id);
        }

        /*    //Creamos un método para validar el Nombre del Torneo, para que no se repita. Lo va a utilizar
            //internamente esta clase, por eso lo declaramos private, y no lo firmamos en IRTorneo
        private bool Existe(Torneo torneo)
        {
            bool ex = false;
            var tor = _appContext.Torneos.FirstOrDefault(t => t.Nombre == torneo.Nombre); //Funciona como un Foreach. Hace la busqueda con el parámetro torneo.Nombre y cuando encuentra el primero se detiene
            if(tor != null)
            {
                ex = true;
            }
            return ex;
        }
        */
    }
}