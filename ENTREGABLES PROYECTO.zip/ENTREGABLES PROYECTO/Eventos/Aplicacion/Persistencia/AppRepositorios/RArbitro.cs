using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia
{
            /*  La clase RArbitro implementa al repositorio IRArbitro. 
                No es una Herencia, se llama IMPLEMENTAR, porque la herencia es entre clases
                y RArbitro es una clase, pero IRArbitro es una interfaz */

    public class RArbitro : IRArbitro
    {
            /*  Atributos
                Necesitamos la conexión a la BD, porque desde aquí se van a crear los metodos CRUD.
                Para ello debemos hacer uso de la cadena de conexión AppContext
        
                Creamos un objeto llamado _appContext de tipo de dato AppContext */

        private readonly AppContext _appContext;

            //......................Métodos.....................
            
        public RArbitro(AppContext appContext)       //Constructor
        {
            this._appContext = appContext;
        }
            //..................................................

        public IEnumerable<Arbitro> ListarArbitros()                //Retorna todos los Árbitros que estan en la BD
        {
            return this._appContext.Arbitros;
        }
            //..................................................

        public List<Arbitro> ListarArbitros1()
        {
            return this._appContext.Arbitros.ToList();               //Para que retorne una lista le ponemos .ToList()
        }
            //..................................................

        public bool CrearArbitro(Arbitro arbitro)                   //Validamos Nombre con IsUnique() en AppContext
        {
            bool creado=false;
            try
            {
                this._appContext.Arbitros.Add(arbitro);
                this._appContext.SaveChanges();
                creado=true;
            }
            catch (System.Exception)
            {
                creado=false;
            }
            return creado;
        }
            //..................................................

        public bool ActualizarArbitro(Arbitro arbitro)
        {
            bool actualizado=false;                                 
            var arb = this._appContext.Arbitros.Find(arbitro.Id);     //Como vamos a buscar por la PK que es un valor entero usamos el método .Find()
            if(arb != null)                                           //Usamos un objeto temporal que vamos a llamar arb que va a tener los datos del registro de la BD 
            {
                try
                {
                    arb.Documento = arbitro.Documento;
                    arb.Nombres = arbitro.Nombres;
                    arb.Apellidos = arbitro.Apellidos;
                    arb.Deporte = arbitro.Deporte;
                    arb.RH = arbitro.RH;
                    arb.TorneoId = arbitro.TorneoId;
                    arb.ColegioId = arbitro.ColegioId;

                    this._appContext.SaveChanges();
                    actualizado=true;
                }
                catch (System.Exception)
                {
                    actualizado=false;
                }
            }   
            return actualizado;
        }         
            //..................................................

        public bool EliminarArbitro(int id)                         //No se requiere borrar en cascada, Arbitro solo tiene foraneas
        {
            bool eliminado = false;
            var arb = this._appContext.Arbitros.Find(id);           //Como vamos a buscar por la PK que es un valor entero usamos el método .Find()
            if(arb != null)                                         //Usamos un objeto temporal que vamos a llamar arb que va a tener los datos del registro de la BD 
            {
                    try
                    {
                        this._appContext.Arbitros.Remove(arb);
                        this._appContext.SaveChanges();
                        eliminado=true;
                    }
                    catch (System.Exception)
                    {
                        eliminado=false;
                    }                  
            }
            return eliminado;
        }
            //..................................................

        public Arbitro BuscarArbitro(int id)
        {
            return this._appContext.Arbitros.Find(id);
        }
    }
}