using System;
using System.Collections.Generic;
using Dominio;
using System.Linq;

namespace Persistencia
{
    public class RLogin : IRLogin
    {
            //Atributos
            //Para ello debemos hacer uso de la cadena de conexión AppContext
        
            //Creamos un objeto _appContext de tipo de dato AppContext
        private readonly AppContext _appContext;

            //Métodos
            //Constructor
        public RLogin(AppContext appContext)
        {
            this._appContext = appContext;
        }

        public bool CrearLogin(Login login)
        {
                //Vamos a validar con Unique, no con el método Existe. Para eso debemos ir a AppContext y hacer la asignación IsUnique() a Nombre
            bool creado=false;
            try
            {
                this._appContext.Logins.Add(login);
                this._appContext.SaveChanges();
                creado=true;
            }
            catch (System.Exception)
            {
                creado=false;
            }
            return creado;
        } 
        
        public bool Validar(Login obj)
        {
            bool valido = false;
            var login = _appContext.Logins.FirstOrDefault(l => l.Usuario == obj.Usuario 
                                                            && l.Password == obj.Password); //si usuario y contraseña existen, entonces usamos FirstOrDefault
            if(login != null)
            {
                valido = true;
            }
            return valido;
        }
    }
}