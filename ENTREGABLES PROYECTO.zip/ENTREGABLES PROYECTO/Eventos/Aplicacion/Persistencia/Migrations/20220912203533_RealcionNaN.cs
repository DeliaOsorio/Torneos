﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Persistencia.Migrations
{
    public partial class RealcionNaN : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_TorneoEquipos",
                table: "TorneoEquipos");

            migrationBuilder.DropIndex(
                name: "IX_TorneoEquipos_TorneoId",
                table: "TorneoEquipos");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "TorneoEquipos");

            migrationBuilder.AddPrimaryKey(
                name: "PK_TorneoEquipos",
                table: "TorneoEquipos",
                columns: new[] { "TorneoId", "EquipoId" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_TorneoEquipos",
                table: "TorneoEquipos");

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "TorneoEquipos",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_TorneoEquipos",
                table: "TorneoEquipos",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_TorneoEquipos_TorneoId",
                table: "TorneoEquipos",
                column: "TorneoId");
        }
    }
}
