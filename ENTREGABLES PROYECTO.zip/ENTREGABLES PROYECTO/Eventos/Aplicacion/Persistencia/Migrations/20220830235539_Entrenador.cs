﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Persistencia.Migrations
{
    public partial class Entrenador : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Entrenadores",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Documento = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Nombres = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Apellidos = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Genero = table.Column<string>(type: "nvarchar(14)", maxLength: 14, nullable: false),
                    Deporte = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    RH = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: false),
                    FechaNacimiento = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Correo = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Celular = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EquipoId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Entrenadores", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Arbitros_ColegioId",
                table: "Arbitros",
                column: "ColegioId");

            migrationBuilder.AddForeignKey(
                name: "FK_Arbitros_Colegios_ColegioId",
                table: "Arbitros",
                column: "ColegioId",
                principalTable: "Colegios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Arbitros_Colegios_ColegioId",
                table: "Arbitros");

            migrationBuilder.DropTable(
                name: "Entrenadores");

            migrationBuilder.DropIndex(
                name: "IX_Arbitros_ColegioId",
                table: "Arbitros");
        }
    }
}
