﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Persistencia.Migrations
{
    public partial class EscenarioEspacio1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Espacios_EscenarioId",
                table: "Espacios",
                column: "EscenarioId");

            migrationBuilder.AddForeignKey(
                name: "FK_Espacios_Escenarios_EscenarioId",
                table: "Espacios",
                column: "EscenarioId",
                principalTable: "Escenarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Espacios_Escenarios_EscenarioId",
                table: "Espacios");

            migrationBuilder.DropIndex(
                name: "IX_Espacios_EscenarioId",
                table: "Espacios");
        }
    }
}
