﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Persistencia.Migrations
{
    public partial class etiquetas : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Deportistas_Equipos_EquipoId",
                table: "Deportistas");

            migrationBuilder.CreateIndex(
                name: "IX_Deportistas_Documento",
                table: "Deportistas",
                column: "Documento",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Deportistas_Equipos_EquipoId",
                table: "Deportistas",
                column: "EquipoId",
                principalTable: "Equipos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Deportistas_Equipos_EquipoId",
                table: "Deportistas");

            migrationBuilder.DropIndex(
                name: "IX_Deportistas_Documento",
                table: "Deportistas");

            migrationBuilder.AddForeignKey(
                name: "FK_Deportistas_Equipos_EquipoId",
                table: "Deportistas",
                column: "EquipoId",
                principalTable: "Equipos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
