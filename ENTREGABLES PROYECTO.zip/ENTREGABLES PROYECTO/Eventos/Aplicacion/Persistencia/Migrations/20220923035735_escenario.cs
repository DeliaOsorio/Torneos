﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Persistencia.Migrations
{
    public partial class escenario : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Espacio_Escenarios_EscenarioId",
                table: "Espacio");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Espacio",
                table: "Espacio");

            migrationBuilder.RenameTable(
                name: "Espacio",
                newName: "Espacios");

            migrationBuilder.RenameIndex(
                name: "IX_Espacio_EscenarioId",
                table: "Espacios",
                newName: "IX_Espacios_EscenarioId");

            migrationBuilder.AlterColumn<string>(
                name: "Correo",
                table: "Deportistas",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(40)",
                oldMaxLength: 40);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Espacios",
                table: "Espacios",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_Escenarios_Nombre",
                table: "Escenarios",
                column: "Nombre",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Espacios_Nombre",
                table: "Espacios",
                column: "Nombre",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Espacios_Escenarios_EscenarioId",
                table: "Espacios",
                column: "EscenarioId",
                principalTable: "Escenarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Espacios_Escenarios_EscenarioId",
                table: "Espacios");

            migrationBuilder.DropIndex(
                name: "IX_Escenarios_Nombre",
                table: "Escenarios");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Espacios",
                table: "Espacios");

            migrationBuilder.DropIndex(
                name: "IX_Espacios_Nombre",
                table: "Espacios");

            migrationBuilder.RenameTable(
                name: "Espacios",
                newName: "Espacio");

            migrationBuilder.RenameIndex(
                name: "IX_Espacios_EscenarioId",
                table: "Espacio",
                newName: "IX_Espacio_EscenarioId");

            migrationBuilder.AlterColumn<string>(
                name: "Correo",
                table: "Deportistas",
                type: "nvarchar(40)",
                maxLength: 40,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Espacio",
                table: "Espacio",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Espacio_Escenarios_EscenarioId",
                table: "Espacio",
                column: "EscenarioId",
                principalTable: "Escenarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
