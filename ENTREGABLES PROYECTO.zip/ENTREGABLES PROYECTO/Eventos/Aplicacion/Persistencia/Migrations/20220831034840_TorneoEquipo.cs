﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Persistencia.Migrations
{
    public partial class TorneoEquipo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Espacios_Escenarios_EscenarioId",
                table: "Espacios");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Espacios",
                table: "Espacios");

            migrationBuilder.RenameTable(
                name: "Espacios",
                newName: "Espacio");

            migrationBuilder.RenameColumn(
                name: "EquipoId",
                table: "Arbitros",
                newName: "TorneoId");

            migrationBuilder.RenameIndex(
                name: "IX_Espacios_EscenarioId",
                table: "Espacio",
                newName: "IX_Espacio_EscenarioId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Espacio",
                table: "Espacio",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "TorneoEquipos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EquipoId = table.Column<int>(type: "int", nullable: false),
                    TorneoId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TorneoEquipos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TorneoEquipos_Equipos_EquipoId",
                        column: x => x.EquipoId,
                        principalTable: "Equipos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TorneoEquipos_Torneos_TorneoId",
                        column: x => x.TorneoId,
                        principalTable: "Torneos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Equipos_PatrocinadorId",
                table: "Equipos",
                column: "PatrocinadorId");

            migrationBuilder.CreateIndex(
                name: "IX_Arbitros_TorneoId",
                table: "Arbitros",
                column: "TorneoId");

            migrationBuilder.CreateIndex(
                name: "IX_TorneoEquipos_EquipoId",
                table: "TorneoEquipos",
                column: "EquipoId");

            migrationBuilder.CreateIndex(
                name: "IX_TorneoEquipos_TorneoId",
                table: "TorneoEquipos",
                column: "TorneoId");

            migrationBuilder.AddForeignKey(
                name: "FK_Arbitros_Torneos_TorneoId",
                table: "Arbitros",
                column: "TorneoId",
                principalTable: "Torneos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Equipos_Patrocinadores_PatrocinadorId",
                table: "Equipos",
                column: "PatrocinadorId",
                principalTable: "Patrocinadores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Espacio_Escenarios_EscenarioId",
                table: "Espacio",
                column: "EscenarioId",
                principalTable: "Escenarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Arbitros_Torneos_TorneoId",
                table: "Arbitros");

            migrationBuilder.DropForeignKey(
                name: "FK_Equipos_Patrocinadores_PatrocinadorId",
                table: "Equipos");

            migrationBuilder.DropForeignKey(
                name: "FK_Espacio_Escenarios_EscenarioId",
                table: "Espacio");

            migrationBuilder.DropTable(
                name: "TorneoEquipos");

            migrationBuilder.DropIndex(
                name: "IX_Equipos_PatrocinadorId",
                table: "Equipos");

            migrationBuilder.DropIndex(
                name: "IX_Arbitros_TorneoId",
                table: "Arbitros");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Espacio",
                table: "Espacio");

            migrationBuilder.RenameTable(
                name: "Espacio",
                newName: "Espacios");

            migrationBuilder.RenameColumn(
                name: "TorneoId",
                table: "Arbitros",
                newName: "EquipoId");

            migrationBuilder.RenameIndex(
                name: "IX_Espacio_EscenarioId",
                table: "Espacios",
                newName: "IX_Espacios_EscenarioId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Espacios",
                table: "Espacios",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Espacios_Escenarios_EscenarioId",
                table: "Espacios",
                column: "EscenarioId",
                principalTable: "Escenarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
