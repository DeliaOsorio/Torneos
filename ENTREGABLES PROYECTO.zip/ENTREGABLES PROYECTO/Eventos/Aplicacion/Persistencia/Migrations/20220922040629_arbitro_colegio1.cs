﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Persistencia.Migrations
{
    public partial class arbitro_colegio1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Arbitros_Colegios_ColegioId",
                table: "Arbitros");

            migrationBuilder.AddForeignKey(
                name: "FK_Arbitros_Colegios_ColegioId",
                table: "Arbitros",
                column: "ColegioId",
                principalTable: "Colegios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Arbitros_Colegios_ColegioId",
                table: "Arbitros");

            migrationBuilder.AddForeignKey(
                name: "FK_Arbitros_Colegios_ColegioId",
                table: "Arbitros",
                column: "ColegioId",
                principalTable: "Colegios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
