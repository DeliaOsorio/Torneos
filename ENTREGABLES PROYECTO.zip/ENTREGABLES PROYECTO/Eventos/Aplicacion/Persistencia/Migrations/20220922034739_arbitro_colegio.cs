﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Persistencia.Migrations
{
    public partial class arbitro_colegio : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Colegios_Nit",
                table: "Colegios",
                column: "Nit",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Arbitros_Documento",
                table: "Arbitros",
                column: "Documento",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Colegios_Nit",
                table: "Colegios");

            migrationBuilder.DropIndex(
                name: "IX_Arbitros_Documento",
                table: "Arbitros");
        }
    }
}
