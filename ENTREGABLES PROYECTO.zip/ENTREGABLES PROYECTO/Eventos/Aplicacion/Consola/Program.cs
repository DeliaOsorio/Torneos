﻿using System;
using Dominio;
using Persistencia;
using System.Collections.Generic; //para que reconozca el List como tipo de dato

namespace Consola
{
    class Program
    {
            //Variables globales
        static int op=0;

            //Instanciamos un objeto de RMunicipio, pero no de tipo RMunicipio sino de tipo
            //IRMunicipio. El objeto _repoMunicipio lo instanciamos con new no como la interfaz sino
            //como la clase RMunicipio, y el constructor de la clase RMunicipio recibe un AppContext: 
        static IRMunicipio _repoMunicipio = new RMunicipio(new Persistencia.AppContext());
        static IRPatrocinador _repoPatrocinador = new RPatrocinador(new Persistencia.AppContext());
        
            //Este objeto _repoMunicipio (se conecta con Persistencia) es el que va a estar facultado para llamar a todos los métodos
            //que tenemos en la clase RMunicipio, la cual implementó todos los métodos de IRMunicipio
        
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!"); //en Java es System.out.println()
            menu();
        }

        //Creación de funciones
        //En ambiente de Consola esto debe ser static
        private static void menu()
        {
            Console.WriteLine();
            Console.WriteLine("*** MENÚ DE OPCIONES ***");
            Console.WriteLine("1. Crear Municipio");
            Console.WriteLine("2. Buscar Municipio");
            Console.WriteLine("3. Actualizar Municipio");
            Console.WriteLine("4. Eliminar Municipio");
            Console.WriteLine("5. Listar Municipio");
            Console.WriteLine(". . . . . . . . . . . . . .");
            Console.WriteLine("6. Crear Patrocinador");
            Console.WriteLine("7. Eliminar Patrocinador");
            Console.WriteLine();
            Console.WriteLine("Seleccione la acción que desea realizar (1..5): ");
            
            //Para capturar la opcion digitada por el usuario, necesitamos convertirla a entero con int.Parse(),
            //porque la entrada por teclado siempre es un string y la variable op la declaramos int
            op = int.Parse(Console.ReadLine());

            switch (op)
            {
                case 1:
                {
                    addMunicipio();
                    break;
                }
                case 2:
                {
                    buscarMunicipio();
                    break;
                }
                case 3:
                {
                    actualizarMunicipio();
                    break;
                }
                case 4:
                {
                    eliminarMunicipio();
                    break;
                }
                case 5:
                {
                    listarMunicipios();
                    break;
                }
                case 6:
                {
                    addPatrocinador();
                    break;
                }
                case 7:
                {
                    eliminarPatrocinador();
                    break;
                }
                default:
                {
                    Console.WriteLine("Favor ingrese una opción válida (1..5)");
                    recargar();
                    break;
                }
            }
        }

        private static void addMunicipio()
        {
            //Console.WriteLine("Adicionar municipio");
            Municipio objMunicipio = new Municipio();
            Console.WriteLine("Ingrese el nombre del nuevo municipio");
            objMunicipio.Nombre = Console.ReadLine();
            bool funciono = _repoMunicipio.CrearMunicipio(objMunicipio);
            if(funciono)
            {
                Console.WriteLine("Municipio adicionado correctamente...");
                recargar();
            }
            else
            {
                Console.WriteLine("Error creando el municipio...");
                recargar();
            }
        }

        private static void buscarMunicipio()
        {
            //Console.WriteLine("Buscar municipio");
            Municipio mun = null;
            Console.WriteLine("Ingrese el Id del municipio que desea buscar:");
            mun = _repoMunicipio.BuscarMunicipio(int.Parse(Console.ReadLine()));
            if(mun != null)
            {
                Console.WriteLine(mun.Id);
                Console.WriteLine(mun.Nombre);
                recargar();
            }
            else
            {
                Console.WriteLine("Municipio no encontrado...");
                recargar();
            }
        }

        private static void actualizarMunicipio()
        {
            //Console.WriteLine("Actualizar municipio");
            Municipio mun = new Municipio();
            Console.WriteLine("Ingrese el Id del municipio que desea modificar");
            mun.Id = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el nuevo nombre del municipio");
            mun.Nombre = Console.ReadLine();

            bool funciono = _repoMunicipio.ActualizarMunicipio(mun);
            if(funciono)
            {
                Console.WriteLine("Municipio actualizado con exito");
                recargar();
            }
            else
            {
                Console.WriteLine("No fue posible aplicar la modificación de municipio");
                recargar();
            }
        }

        private static void eliminarMunicipio()
        {
            //Console.WriteLine("Eliminar municipio");
            int id=0;
            Console.WriteLine("Ingrese el Id del municipio a Eliminar: ");
            id = int.Parse(Console.ReadLine());

            bool funciono = _repoMunicipio.EliminarMunicipio(id);
            if(funciono)
            {
                Console.WriteLine("Municipio eliminado con exito.");
                recargar();
            }
            else
            {
                Console.WriteLine("No fue posible eliminar el  Municipio.");
                recargar();
            }
        }

        private static void listarMunicipios()
        {
            //Console.WriteLine("Listar municipios");
            List<Municipio> lstMunicipios = _repoMunicipio.ListarMunicipios1();
            foreach (var mun in lstMunicipios)
            {
                Console.WriteLine(mun.Id +" "+ mun.Nombre);
            }
            recargar();
        }

        private static void recargar()
        {
            Console.WriteLine("Presione una tecla para continuar...");
            Console.ReadLine();
            Console.Clear();
            menu();
        }

        private static void addPatrocinador()
        {
            //Console.WriteLine("Adicionar patrocinador");
            Patrocinador objPatrocinador = new Patrocinador();
            Console.WriteLine("Ingrese el nombre del nuevo patrocinador");
            objPatrocinador.Nombre = Console.ReadLine();
            bool funciono = _repoPatrocinador.CrearPatrocinador(objPatrocinador);
            if(funciono)
            {
                Console.WriteLine("Patrocinador adicionado correctamente...");
                recargar();
            }
            else
            {
                Console.WriteLine("Error creando el patrocinador...");
                recargar();
            }
        }

        private static void eliminarPatrocinador()
        {
            //Console.WriteLine("Eliminar patrocinador");
            int id=0;
            Console.WriteLine("Ingrese el Id del patrocinador a Eliminar: ");
            id = int.Parse(Console.ReadLine());

            bool funciono = _repoPatrocinador.EliminarPatrocinador(id);
            if(funciono)
            {
                Console.WriteLine("Patrocinador eliminado con exito.");
                recargar();
            }
            else
            {
                Console.WriteLine("No fue posible eliminar el Patrocinador.");
                recargar();
            }
        }
    }
}
