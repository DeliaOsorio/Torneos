using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Persistencia;

namespace Frontend
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //ESTA CONFIGURACION ES MUY IMPORTANTE PARA LA FUNCIONALIDAD WEB
            services.AddRazorPages();

            //Le inyectamos o agregamos el contexto UNA SOLA VEZ
            services.AddDbContext<Persistencia.AppContext>();

            //HACER LAS INYECCIONES DE CADA INTERFAZ CON SU CLASE (Inyectamos unas dependencias de uso, UNA POR CADA ENTIDAD):
            services.AddScoped<IRMunicipio, RMunicipio>();
            services.AddScoped<IRPatrocinador, RPatrocinador>();
            services.AddScoped<IRTorneo, RTorneo>();
            services.AddScoped<IREquipo, REquipo>();
            services.AddScoped<IREntrenador, REntrenador>();
            services.AddScoped<IRTorneoEquipo, RTorneoEquipo>();
            services.AddScoped<IRLogin, RLogin>();
            services.AddScoped<IRColegio, RColegio>();
            services.AddScoped<IRArbitro, RArbitro>();
            services.AddScoped<IRDeportista, RDeportista>();
            services.AddScoped<IREscenario,REscenario>();
            services.AddScoped<IREspacio,REspacio>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
            });
        }
    }
}
