using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CPatrocinador
{
    public class IndexModel : PageModel
    {
            //Llamando al repositorio RMunicipio podemos saber cuántos registros tiene la tabla
            //Atributos
        private readonly IRPatrocinador _repoPat;
        public IEnumerable<Patrocinador> Patrocinadores {get;set;}

            //Metodos
            //Constructor
        public IndexModel(IRPatrocinador repoPat)
        {
            this._repoPat=repoPat;
        }

            //Llevar información a la página web vinculada, es decir a la pagina index.cshtml
        public void OnGet()
        {
            Patrocinadores = _repoPat.ListarPatrocinadores();
        }
    }
}
