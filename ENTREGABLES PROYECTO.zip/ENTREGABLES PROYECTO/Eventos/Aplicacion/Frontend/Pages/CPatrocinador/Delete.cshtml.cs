using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CPatrocinador
{
    public class DeleteModel : PageModel
    {
            //Atributos
        private readonly IRPatrocinador _repoPat;

            //tenemos una propiedad vinculada que se va a llamar también Municipio.
            //Vincula la propiedad con el modelo para el momento de la captura. Para que tenga la propiedad de conectarse con los dataAnnotations
        [BindProperty]
        public Patrocinador Patrocinador {get; set;}

            //Metodos
            //Constructor
        public DeleteModel(IRPatrocinador repoPat)
        {
            this._repoPat = repoPat;
        }
        
            //El OnGet se encarga de colocar informacion en esa nueva vista y para eso hace una Búsqueda por Id, a diferencia del de Create.
            //tambien retorna algo por eso es de tipo ActionResult y le llega como parámetro un entero Id
            //El método OnGet solo adapta la vista, pero el que en realidad elimina es el metodo OnPost
        public ActionResult OnGet(int Id) 
        {
                //se llama al metodo buscar que se encuentra en RMunicipio de la Persistencia y se le envía el Id
            Patrocinador = _repoPat.BuscarPatrocinador(Id);
            return Page();
        }

        //Eliminamos con el método OnPost y no recibe ningún parámetro
        public ActionResult OnPost()
        {
            bool funciono = _repoPat.EliminarPatrocinador(Patrocinador.Id); //Llamamos el metodo EliminarMunicipio de RPatrocinador y le enviamos el Patrocinador del OnGet
            if (funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="No es posible eliminar el Patrocinador porque al menos un Equipo lo contiene (integridad referencial)";
                return Page();
            }
        }
    }
}
