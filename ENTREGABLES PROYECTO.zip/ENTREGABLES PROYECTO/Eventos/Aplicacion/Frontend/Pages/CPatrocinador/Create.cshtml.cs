using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CPatrocinador
{
    public class CreateModel : PageModel
    {
        //Atributos
        private readonly IRPatrocinador _repoPat;

        [BindProperty] //Vincula la propiedad con el modelo para el momento de la captura. Para que tenga la propiedad de conectarse con los dataAnnotations
        public Patrocinador Patrocinador {get; set;}
        
        //Metodos
        //Constructor
        public CreateModel(IRPatrocinador repoPat)
        {
            this._repoPat = repoPat;
        }

        //Se encarga de mostrar información o mostrar nuevos formularios
        public ActionResult OnGet()
        {
            return Page(); //retorna la página que esta ligada a este modelo, es decir, la pagina Create
        }

        //Método que recibe la información desde un formulario
        public ActionResult OnPost()
        {
            if(!ModelState.IsValid) //Método que se encarga de validar la calidad de datos que estan ingresando en el formulario
            {
                return Page();
            }

            bool funciono = _repoPat.CrearPatrocinador(Patrocinador);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"] = "Ya hay registrado un Patrocinador con el documento " + Patrocinador.Documento;
                return Page();
            }
        }
    }
}
