using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CArbitro
{
    public class DetailsModel : PageModel
    {
             //Vamos a manejar tres objetos, para el repositorio de Entrenador y el repositorio de Colegio y Torneo: 
        private readonly IRArbitro _repoArbitro;
        private readonly IRColegio _repoColegio;
        private readonly IRTorneo _repoTorneo;

            //Vamos a tener tres propiedades vinculadas:
        [BindProperty]
        public Arbitro Arbitro {get; set;}
        public Colegio Colegio {get;set;}         //De esta propiedad vinculada sacaremos el Nombre del colegio
        public Torneo Torneo {get;set;}           //De esta propiedad vinculada sacaremos el Nombre del Torneo

            //Constructor
            //Se inicializan los tres objetos:
        public DetailsModel(IRArbitro repoArbitro, IRColegio repoColegio, IRTorneo repoTorneo)
        {
            this._repoArbitro = repoArbitro;
            this._repoColegio = repoColegio;
            this._repoTorneo = repoTorneo;
        }

            //El OnGet debe devolver la información tanto del municipio como del Torneo
        public ActionResult OnGet(int id)
        {
            Arbitro = _repoArbitro.BuscarArbitro(id);
            Colegio = _repoColegio.BuscarColegio(Arbitro.ColegioId);
            Torneo = _repoTorneo.BuscarTorneo(Arbitro.TorneoId);

            if(Arbitro == null)
            {
                ViewData["Error"]="Arbitro no encontrado";
                return Page();
            }
            return Page();
        }
            //Los detalles no necesitan el método OnPost
    }
}
