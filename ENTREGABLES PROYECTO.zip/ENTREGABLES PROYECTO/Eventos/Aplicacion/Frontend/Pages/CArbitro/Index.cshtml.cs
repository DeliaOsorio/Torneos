using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CArbitro
{
    public class IndexModel : PageModel
    {
            //Atributos: dos objetos derivados de los repositorios, _repoArbitro y _repoColegio
        private readonly IRArbitro _repoArbitro;

            //Colegio depende de arbitro, para poderlos relacionar necesitamos tener también acceso a los Colegios:
        private readonly IRColegio _repoColegio;
            //Con los Colegios y los Arbitros podemos armar los ArbitrosView el cual vamos a llevar al Index

        [BindProperty]
        public IEnumerable<Arbitro> Arbitros {get;set;}
       
        public List<ArbitroView> ArbitrosView = new List<ArbitroView>();

            //Métodos
            //Constructor
        public IndexModel(IRColegio repoColegio, IRArbitro repoArbitro)
        {
            this._repoColegio = repoColegio;
            this._repoArbitro = repoArbitro;
        }

            //El OnGet devuelve al usuario una vista con los elementos que esta necesitando, y allí debemos ver el nombre de los Colegios
        public void OnGet()
        {
                //Creamos una lista de Colegios que la vamos a llamar lstColegios
            List<Colegio> lstColegios = _repoColegio.ListarColegios1();
                
                //Tambien llenamos Arbitros. Aquí tenemos todos los Arbitros
            Arbitros = _repoArbitro.ListarArbitros();
                
                //Con estas dos listas necesitamos llenar la lista ArbitrosView que es la que vamos a llevar a la vista:
            ArbitroView av = null;

            foreach(var a in Arbitros)   //El foreach permite recorrer la lista de Arbitros
            {
                av = new ArbitroView();     //Instanciamos el objeto av de tipo ArbitroView
                foreach(var q in lstColegios)     //otro foreach anidado para recorrer la lista de Colegios
                {
                    if(a.ColegioId == q.Id)
                    {
                        av.Colegio = q.RazonSocial;
                    }
                }
                av.Id = a.Id;
                av.Documento = a.Documento;
                av.Nombres = a.Nombres;
                av.Apellidos = a.Apellidos;

                    //Ya teniendo el objeto av armado, lo agregamos a la lista ArbitrosView
                ArbitrosView.Add(av);
            }    
        }
    }
}
