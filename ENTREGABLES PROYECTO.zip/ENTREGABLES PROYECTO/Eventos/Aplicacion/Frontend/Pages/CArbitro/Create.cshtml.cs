using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CArbitro
{
    public class CreateModel : PageModel
    {
            //Como necesitamos transportar una lista de los Colegios y los Torneos, entonces también necesitamos hacer uso de un repositorio de Colegios _repoColegio y Torneos _repoTorneos
        private readonly IRArbitro _repoArbitro;
        private readonly IRColegio _repoColegio;
        private readonly IRTorneo _repoTorneo;

        [BindProperty]
        public Arbitro Arbitro {get; set;}
        public IEnumerable<Colegio> Colegios {get; set;}
        public IEnumerable<Torneo> Torneos {get; set;}

            //Constructor
        public CreateModel(IRColegio repoColegio, IRArbitro repoArbitro, IRTorneo repoTorneo)
        {
            this._repoArbitro = repoArbitro;
            this._repoColegio = repoColegio;
            this._repoTorneo = repoTorneo;
        }

            //En este OnGet vamos a llenar la lista de Colegios y de Torneos
        public ActionResult OnGet()
        {
            Colegios = this._repoColegio.ListarColegios();

            Torneos = this._repoTorneo.ListarTorneos();

            return Page();
        }

        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Colegios = this._repoColegio.ListarColegios();          //Llenamos la lista antes de que nos muestre los errores en el modelo
                Torneos = this._repoTorneo.ListarTorneos();          //Llenamos la lista antes de que nos muestre los errores en el modelo
                return Page();
            }

            bool funciono = _repoArbitro.CrearArbitro(Arbitro);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Colegios = this._repoColegio.ListarColegios();
                Torneos = this._repoTorneo.ListarTorneos(); 
                ViewData["Error"] = "El documento " + Arbitro.Documento + " ya está registrado. No es posible hacer el registro.";
                return Page();
            }
        }
    }
}
