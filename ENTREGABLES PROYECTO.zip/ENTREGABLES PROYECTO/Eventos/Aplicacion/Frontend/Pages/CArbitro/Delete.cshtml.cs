using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CArbitro
{
    public class DeleteModel : PageModel
    {
             //Necesitamos tres repositorios, del Arbitro, del Torneo y del Colegio
        private readonly IRArbitro _repoArbitro;
        private readonly IRColegio _repoColegio;
        private readonly IRTorneo _repoTorneo;

            //Necesitamos tres propiedades vinculadas para hacer el transporte al front
        [BindProperty]
        public Arbitro Arbitro {get;set;}
        public Colegio Colegio {get;set;}
        public Torneo Torneo {get;set;}

            // Constructor
        public DeleteModel(IRArbitro repoArbitro, IRColegio repoColegio, IRTorneo repoTorneo)
        {
            this._repoArbitro = repoArbitro;
            this._repoColegio = repoColegio;
            this._repoTorneo = repoTorneo;
        }

        public ActionResult OnGet(int id)
        {
            Arbitro = _repoArbitro.BuscarArbitro(id);
            Colegio = _repoColegio.BuscarColegio(Arbitro.ColegioId);
            Torneo = _repoTorneo.BuscarTorneo(Arbitro.TorneoId);

            if(Arbitro == null)
            {
                ViewData["Error"]="Árbitro no encontrado";
                return Page();
            }
            else
            {
                return Page();    
            }
        }

            //Ahora vamos a ejecutar la eliminación
        public ActionResult OnPost()
        {
            bool funciono = _repoArbitro.EliminarArbitro(Arbitro.Id);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="El egistro no se pudo eliminar";
                return Page();
            }
        }
    }
}
