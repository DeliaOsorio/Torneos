using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CArbitro
{
    public class EditModel : PageModel
    {
            // Necesitamos transportar una lista de los Colegios y los Torneos, entonces necesitamos hacer uso de un repositorio de Colegios _repoColegio y otro de Torneos _repoTorneo
        private readonly IRArbitro _repoArbitro;
        private readonly IRColegio _repoColegio;
        private readonly IRTorneo _repoTorneo;

        [BindProperty]
        public Arbitro Arbitro {get; set;}

        public IEnumerable<Colegio> Colegios {get; set;}
        public IEnumerable<Torneo> Torneos {get; set;}

            //Constructor
        public EditModel(IRArbitro repoArbitro, IRColegio repoColegio, IRTorneo repoTorneo)
        {
            this._repoArbitro = repoArbitro;
            this._repoColegio = repoColegio;
            this._repoTorneo = repoTorneo;
        }

            //En este OnGet vamos a llenar la lista de Colegios y Torneos
        public ActionResult OnGet(int id)
        {
            Arbitro = _repoArbitro.BuscarArbitro(id);
            Colegios = this._repoColegio.ListarColegios();
            Torneos = this._repoTorneo.ListarTorneos();

            if(Arbitro == null)
            {
                ViewData["Error"] = "Arbitro no encontrado";
                return Page();
            }
            else
            {
                return Page();
            }
        }

        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Colegios = this._repoColegio.ListarColegios(); //Llenamos la lista antes de que nos muestre los errores en el modelo
                Torneos = this._repoTorneo.ListarTorneos(); 
                return Page();
            }
            bool funciono = _repoArbitro.ActualizarArbitro(Arbitro);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Colegios = this._repoColegio.ListarColegios();
                Torneos = this._repoTorneo.ListarTorneos();
                ViewData["Error"]="No se pueden registrar Árbitros con el mismo Documento";  //En el AppContext se indicó Documento como IsUnique() 
                return Page();
            }
        }
    }
}
