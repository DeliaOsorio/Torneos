using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEspacio
{
    public class DeleteModel : PageModel
    {
                private readonly IREspacio _repoEspacio;

        [BindProperty]
        public Espacio Espacio {set;get;}
        public DeleteModel(IREspacio repoEspacio)
        {
            this._repoEspacio = repoEspacio;
        }
        
        public ActionResult OnGet(int id)
        {
            Espacio = _repoEspacio.BuscarEspacio(id);
            if(Espacio == null)
            {
                ViewData["Error"]="Espacio no encontrado";
                return Page();
            }
            return Page();
        }

        public ActionResult OnPost()
        {
            bool funciono = _repoEspacio.EliminarEspacio(Espacio.Id);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="No es posible eliminar el espacio porque al menos un escenario lo contiene (integridad referencial)";
                return Page();
            }
        }
    }
}
