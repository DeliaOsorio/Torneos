using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEspacio
{
    public class IndexModel : PageModel
    {
        private readonly IREspacio _repoEspacio;
        private readonly IREscenario _repoEscenario;

        [BindProperty]
        public IEnumerable<Espacio> Espacios{set;get;}
        public List<EspacioView> EspaciosView = new List<EspacioView>();
        public List<DeportistaView> DeportistasView = new List<DeportistaView>();

            //Metodos
            //Constructor

        public IndexModel(IREspacio repoEspacio, IREscenario repoEscenario)
        {
            this._repoEspacio = repoEspacio;
            this._repoEscenario = repoEscenario;
        }


        public void OnGet()
        {
            //Espacios = _repoEspacio.ListarEspacios();

            List<Escenario> lstEscenarios = _repoEscenario.ListarEscenarios1();      //Creamos una lista de Escenarios que la vamos a llamar lstEscenarios

            Espacios = _repoEspacio.ListarEspacios();                                 //También llenamos Espacios. Aquí tenemos todos los Espacios

                //Con estas dos listas necesitamos llenar la lista EspaciosView que es la que vamos a llevar a la vista:
            EspacioView dv = null;

            foreach(var d in Espacios)                       //El foreach permite recorrer la lista de Espacios
            {
                dv = new EspacioView();                      //Instanciamos el objeto dv de tipo DeportistaView

                foreach(var e in lstEscenarios)                    //Otro foreach anidado para recorrer la lista de Equipos
                {
                    if(d.EscenarioId == e.Id)
                    {
                        dv.Escenario = e.Nombre;
                    }
                }
                dv.Id = d.Id;
                dv.Nombre = d.Nombre;
                dv.Disciplina = d.Disciplina;
                dv.Espectadores = d.Espectadores;

                    //Ya teniendo el objeto dv armado, lo agregamos a la lista DeportistasView
                EspaciosView.Add(dv);
            } 
        }
    }
}
