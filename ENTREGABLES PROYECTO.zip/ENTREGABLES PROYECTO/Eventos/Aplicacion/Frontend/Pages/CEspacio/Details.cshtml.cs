using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEspacio
{
    public class DetailsModel : PageModel
    {
        private readonly IREspacio _repoEspacio;
        private readonly IREscenario _repoEscenario;

        [BindProperty]
        public Espacio Espacio {set;get;}
        public Escenario Escenario {set;get;}

        public DetailsModel(IREspacio repoEspacio, IREscenario repoEscenario)
        {
            this._repoEspacio = repoEspacio;
            this._repoEscenario = repoEscenario;
        }

        public ActionResult OnGet(int id)
        {
            Espacio = _repoEspacio.BuscarEspacio(id);
            Escenario = _repoEscenario.BuscarEscenario(Espacio.EscenarioId);

            if(Espacio == null)
            {
                ViewData["Error"] = "Espacio no encontrado";
                return Page();
            }
            return Page();
        }
    }
}
