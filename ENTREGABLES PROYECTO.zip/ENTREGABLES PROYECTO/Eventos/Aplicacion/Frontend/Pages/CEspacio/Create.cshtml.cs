using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEspacio
{
    public class CreateModel : PageModel
    {
            private readonly IREspacio _repoEspacio;
            private readonly IREscenario _repoEscenario;

        [BindProperty]
        public Espacio Espacio {set;get;}
        public IEnumerable<Escenario> Escenarios {set;get;}
        
        public CreateModel(IREspacio repoEspacio, IREscenario repoEscenario)
        {
            this._repoEspacio = repoEspacio;
            this._repoEscenario = repoEscenario;
        }

        public ActionResult OnGet()
        {
            Escenarios = this._repoEscenario.ListarEscenarios();
            return Page();
        }

        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Escenarios = this._repoEscenario.ListarEscenarios();
                return Page();
            }

            bool funciono = _repoEspacio.CrearEspacio(Espacio);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Escenarios = this._repoEscenario.ListarEscenarios();
                ViewData["Error"]="No se puede crear el espacio " + Espacio.Nombre +" porque ya existe";
                return Page();
            }
        }
    }
}
