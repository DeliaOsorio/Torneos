using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEspacio
{
    public class EditModel : PageModel
    {
        private readonly IREspacio _repoEspacio;
        private readonly IREscenario _repoEscenario;

        [BindProperty]
        public Espacio Espacio{set;get;}
        public IEnumerable<Escenario> Escenarios {get; set;}

        //Constructor
        public EditModel(IREspacio repoEspacio, IREscenario repoEscenario)
        {
            this._repoEspacio = repoEspacio;
            this._repoEscenario = repoEscenario;
        }

        public ActionResult OnGet(int id)
        {
            Espacio = _repoEspacio.BuscarEspacio(id);
            Escenarios = _repoEscenario.ListarEscenarios();

            if(Espacio == null)
            {
                ViewData["Error"] = "Espacio no encontrado";
                return Page();
            }
            else
            {
                return Page();
            }
        }    
        
        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Escenarios = _repoEscenario.ListarEscenarios();
                return Page();
            }

            bool funciono = _repoEspacio.ActualizarEspacio(Espacio);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Escenarios = _repoEscenario.ListarEscenarios();
                ViewData["Error"]="Ya existe un espacio con el nombre "+ Espacio.Nombre;
                return Page();
            }
        }
    }
}
