using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CColegio
{
    public class DetailsModel : PageModel
    {
        private readonly IRColegio _repoColegio;

            //tenemos una propiedad vinculada que se va a llamar también Colegio.
            //Vincula la propiedad con el modelo para el momento de la captura. Para que tenga la propiedad de conectarse con los dataAnnotations
        [BindProperty]
        public Colegio Colegio {get; set;}

            //Métodos
            //Constructor
        public DetailsModel (IRColegio repoColegio)
        {
            this._repoColegio = repoColegio;
        }

        public ActionResult OnGet(int id)
        {
            Colegio = _repoColegio.BuscarColegio(id);
            return Page();
        }
    }
}
