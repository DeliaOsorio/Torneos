using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CColegio
{
    public class DeleteModel : PageModel
    {
              //Atributos
        private readonly IRColegio _repoColegio;

            //tenemos una propiedad vinculada que se va a llamar también Colegio.
            //Vincula la propiedad con el modelo para el momento de la captura. Para que tenga la propiedad de conectarse con los dataAnnotations
        [BindProperty]
        public Colegio Colegio {get; set;}

            //Metodos
            //Constructor
        public DeleteModel(IRColegio repoColegio)
        {
            this._repoColegio = repoColegio;
        }
        
            //El OnGet se encarga de colocar informacion en esa nueva vista y para eso hace una Búsqueda por Id, a diferencia del de Create.
            //tambien retorna algo por eso es de tipo ActionResult y le llega como parámetro un entero Id
            //El método OnGet solo adapta la vista, pero el que en realidad elimina es el metodo OnPost
        public ActionResult OnGet(int Id) 
        {
                //se llama al metodo buscar que se encuentra en RColegio de la Persistencia y se le envía el Id
            Colegio = _repoColegio.BuscarColegio(Id);
            if (Colegio == null)
            {
                ViewData["Error"]="Colegio no encontrado"; //este if lo estamos haciendo por estandar, porque en realidad el municipio si existe porque lo vemos en el formulario
                                                           //El ViewData representa Datos para la Vista, es una forma fácil de transportar información entre el back (.cshtml.cs) y el front (.cshtml)
                return Page();
            }
            return Page();
        }

            //Eliminamos con el método OnPost y no recibe ningún parámetro
        public ActionResult OnPost()
        {
            bool funciono = _repoColegio.EliminarColegio(Colegio.Id); //Llamamos el metodo EliminarColegio de RColegio y le enviamos el Colegio.Id del OnGet
            if (funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="No es posible eliminar el Colegio porque al menos un Árbitro lo contiene (integridad referencial)";
                return Page();
            }
        }
    }
}
