using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CColegio
{
    public class EditModel : PageModel
    {
            //Atributos. Un objeto de la interfaz IRColegio
        private readonly IRColegio _repoColegio;

            //tenemos una propiedad vinculada que se va a llamar también Colegio.
            //Vincula la propiedad con el modelo para el momento de la captura. Para que tenga la propiedad de conectarse con los dataAnnotations
        [BindProperty]
        public Colegio Colegio {get; set;}

            //Métodos
            //Constructor
        public EditModel(IRColegio repoColegio)
        {
            this._repoColegio = repoColegio;
        }

            //El método OnGet se encarga de llevar a la vista nuevas páginas vacias (como el Create) o con información del registro que se seleccionó en el Index (como este caso Edit)
            //para eso se hace una búsqueda por Id
        public ActionResult OnGet(int Id)
        {
                //Hacemos la búsqueda. Al objeto Colegio que es la propiedad vinculada lo llenamos por medio de una búsqueda, utilizando el método BuscarColegio de RColegio
            Colegio = _repoColegio.BuscarColegio(Id);
            return Page();
        }

            //Hasta aquí con el método OnGet pintamos la vista y mostramos información
            //El método OnPost se encarga de recoger lo que el usuario digita y da clic en el boton Editar y aplica la modificación llamando un método que modifique, en este caso ActualizarColegio de RColegio
        public ActionResult OnPost()
        {
                //primero validamos el modelo para que se conecte con las validaciones
            if(!ModelState.IsValid)
            {
                return Page();
            }
            bool funciono = _repoColegio.ActualizarColegio(Colegio);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="Ya existe un colegio con el Nombre: " + Colegio.RazonSocial;
                return Page();
            }
        }
    }
}
