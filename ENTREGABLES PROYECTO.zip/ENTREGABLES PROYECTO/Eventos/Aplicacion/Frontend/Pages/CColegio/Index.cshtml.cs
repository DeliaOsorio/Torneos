using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CColegio
{
    public class IndexModel : PageModel
    {
            //Llamando al repositorio RColegio podemos saber cuántos registros tiene la tabla
            //Atributos
        private readonly IRColegio _repoColegio;
        public IEnumerable<Colegio> Colegios {get;set;}

            //Metodos
            //Constructor
        public IndexModel(IRColegio repoColegio)
        {
            this._repoColegio = repoColegio;
        }

            //Llevar información a la página web vinculada, es decir a la pagina index.cshtml
        public void OnGet()
        {
            Colegios = _repoColegio.ListarColegios();
        }
    }
}
