using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEscenario
{
    public class DetailsModel : PageModel
    {
             private readonly IREscenario _repoEscenario;
        private readonly IRTorneo _repoTorneo;

        [BindProperty]
        public Escenario Escenario {set;get;}
        public Torneo Torneo{set;get;}

        public DetailsModel(IREscenario repoEscenario, IRTorneo repoTorneo)
        {
            this._repoEscenario = repoEscenario;
            this._repoTorneo = repoTorneo;
        }

        public ActionResult OnGet(int id)
        {
            Escenario = _repoEscenario.BuscarEscenario(id);
            Torneo = _repoTorneo.BuscarTorneo(Escenario.TorneoId);

            if(Escenario == null)
            {
                ViewData["Error"]="Escenario no encontrado";
                return Page();
            }
            return Page();
        }
    }
}
