using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEscenario
{
    public class EditModel : PageModel
    {
           private readonly IREscenario _repoEscenario;
        private readonly IRTorneo _repoTorneo;

        [BindProperty]
        public Escenario Escenario{set;get;}
        public IEnumerable<Torneo> Torneos{set;get;}


        //Constructor
        public EditModel(IREscenario repoEscenario, IRTorneo repoTorneo)
        {
            this._repoEscenario = repoEscenario;
            this._repoTorneo = repoTorneo;
        }

        public ActionResult OnGet(int id)
        {
            Escenario = _repoEscenario.BuscarEscenario(id);
            Torneos = _repoTorneo.ListarTorneos();
            
            if(Escenario == null)
            {
                ViewData["Error"]= "Escenario no encontrado";
                return Page();
            }
            else
            {
                return Page();
            }
        }

        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Torneos = _repoTorneo.ListarTorneos();
                return Page();
            }
            bool funciono = _repoEscenario.ActualizarEscenario(Escenario);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Torneos = _repoTorneo.ListarTorneos();
                ViewData["Error"]="Ya existe un escenario con el nombre "+ Escenario.Nombre;
                return Page();
            }
        }
    }
}
