using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEscenario
{
    public class IndexModel : PageModel
    {
        private readonly IREscenario _repoEscenario;
        private readonly IRTorneo _repoTorneo; 

        [BindProperty]
        public IEnumerable<Escenario> Escenarios {set;get;}
        public List<EscenarioView> EscenariosView = new List<EscenarioView>();

        //metodos
        //Constructor
        public IndexModel(IREscenario repoEscenario,IRTorneo repoTorneo)
        {
            this._repoEscenario = repoEscenario;
            this._repoTorneo = repoTorneo; 
        }

        public void OnGet()
        {
            List<Torneo> lstTorneos = _repoTorneo.ListarTorneos1();
            Escenarios = _repoEscenario.ListarEscenarios();

            EscenarioView ev = null;

            foreach (var e in Escenarios)
            {
                ev = new EscenarioView();
                foreach (var q in lstTorneos)
                {
                    if(e.TorneoId==q.Id)
                    {
                        ev.Torneo = q.Nombre;
                    }
                }
                ev.Id = e.Id;
                ev.Direccion = e.Direccion;
                ev.Nombre = e.Nombre;
                EscenariosView.Add(ev);
            }
        }
    }
}
