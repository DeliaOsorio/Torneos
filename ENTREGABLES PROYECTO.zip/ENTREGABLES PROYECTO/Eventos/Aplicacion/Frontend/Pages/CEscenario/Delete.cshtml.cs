using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEscenario
{
    public class DeleteModel : PageModel
    {
        private readonly IREscenario _repoEscenario;
        private readonly IRTorneo _repoTorneo;

        [BindProperty]
        public Escenario Escenario {set;get;}
        public Torneo Torneo {set;get;}

        public DeleteModel(IREscenario repoEscenario, IRTorneo repoTorneo)
        {
            this._repoTorneo = repoTorneo;
            this._repoEscenario = repoEscenario;
        }
        
        public ActionResult OnGet(int id)
        {
            Escenario = _repoEscenario.BuscarEscenario(id);
            Torneo =_repoTorneo.BuscarTorneo(Escenario.TorneoId);
            if(Escenario == null)
            {
                ViewData["Error"]="Escenario no encontrado";
                return Page();
            }
            else
            {
                return Page();    
            }
        }

        public ActionResult OnPost()
        {
            bool funciono = _repoEscenario.EliminarEscenario(Escenario.Id);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="No es posible eliminar el escenario porque al menos un Torneo lo contiene (integridad referencial)";
                return Page();
            }
        }
    }
}
