using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CDeportista
{
    public class EditModel : PageModel
    {
        private readonly IRDeportista _repoDeportista;
        private readonly IREquipo _repoEquipo;

        [BindProperty]
        public Deportista Deportista {get;set;}           //La propiedad Deportista
        public IEnumerable<Equipo> Equipos {get;set;}     //Una lista de Equipos

            //Constructor
        public EditModel(IRDeportista repoDeportista, IREquipo repoEquipo)
        {
            this._repoDeportista = repoDeportista;
            this._repoEquipo = repoEquipo;
        }

        public ActionResult OnGet(int id)
        {
            Deportista = _repoDeportista.BuscarDeportista(id);
            Equipos = _repoEquipo.ListarEquipos();       //IEnumerable

            if(Deportista == null)
            {
                ViewData["Error"] = "Deportista no encontrado";
                return Page();
            }
            else
            {
                return Page();
            }
        }   //Hasta aquí muestra la información en pantalla

        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Equipos = _repoEquipo.ListarEquipos();   //Que llene nuevamente la lista de Equipos, para que no genere errores
                return Page();
            }

            bool funciono = _repoDeportista.ActualizarDeportista(Deportista);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Equipos = _repoEquipo.ListarEquipos();   //Que llene nuevamente la lista de Equipos, para que no genere errores
                ViewData["Error"]="Ya existe un Deportista con el documento " + Deportista.Documento;   //En el AppContext se indicó Documento como IsUnique
                //ViewData["Error"]="No puede duplicar los valores de documento y/o equipo";
                return Page();
            }
        }
    }
}
