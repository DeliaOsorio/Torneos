using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CDeportista
{
    public class DeleteModel : PageModel
    {
            //Necesitamos dos repositorios, del Deportista y del Equipo
        private readonly IRDeportista _repoDeportista;
        private readonly IREquipo _repoEquipo;
        
            //Necesitamos dos propiedades vinculadas para hacer el transporte al front
        [BindProperty]
        public Deportista Deportista {get;set;}
        public Equipo Equipo {get;set;}

        public DeleteModel(IRDeportista repoDeportista, IREquipo repoEquipo)
        {
            this._repoDeportista = repoDeportista;
            this._repoEquipo = repoEquipo;
        }
            //------------------------------------------------
        public ActionResult OnGet(int id)
        {
            Deportista = _repoDeportista.BuscarDeportista(id);             //Llenamos el objeto Deportista buscando con el "Id del Deportista" que envian del front
            Equipo = _repoEquipo.BuscarEquipo(Deportista.EquipoId);        //Llenamos el objeto Equipo buscando en Equipos el Id que entrega "EquipoId de Deportista"
            if(Deportista == null)
            {
                ViewData["Error"]="Deportista no encontrado";
                return Page();
            }
            else
            {
                return Page();    
            }
        }
            //-------------------------------------------------
            //Ahora vamos a ejecutar la eliminación
        public ActionResult OnPost()
        {
            bool funciono = _repoDeportista.EliminarDeportista(Deportista.Id);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="El registro no se pudo eliminar";
                return Page();
            }
        }
    }
}
