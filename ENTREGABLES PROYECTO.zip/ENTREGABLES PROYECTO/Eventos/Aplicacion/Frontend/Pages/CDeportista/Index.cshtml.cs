using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CDeportista
{
    public class IndexModel : PageModel
    {
             //Atributos: dos objetos derivados de los repositorios, _repoDeportista y _repoEquipo
        private readonly IRDeportista _repoDeportista;

            // Deportista depende de Equipo, para poderlos relacionar necesitamos tener también acceso a los Equipos:
        private readonly IREquipo _repoEquipo;

            //Con los Equipos y los Deportistas podemos armar los DeportistasView el cual vamos a llevar al Index

        [BindProperty]
        public IEnumerable<Deportista> Deportistas {get;set;}
        public List<DeportistaView> DeportistasView = new List<DeportistaView>();

            //Métodos
            //Constructor
        public IndexModel(IRDeportista repoDeportista, IREquipo repoEquipo)
        {
            this._repoDeportista = repoDeportista;
            this._repoEquipo = repoEquipo;
        }

            //El OnGet devuelve al usuario una vista con los elementos que esta necesitando, y allí debemos ver el nombre de los Deportistas
        public void OnGet()
        { 
            List<Equipo> lstEquipos = _repoEquipo.ListarEquipos1();            //Creamos una lista de Equipos que la vamos a llamar lstEquipos

            Deportistas = _repoDeportista.ListarDeportistas();                 //También llenamos Deportistas. Aquí tenemos todos los Deportistas

                //Con estas dos listas necesitamos llenar la lista DeportistasView que es la que vamos a llevar a la vista:
            DeportistaView dv = null;

            foreach(var d in Deportistas)                       //El foreach permite recorrer la lista de Deportistas
            {
                dv = new DeportistaView();                      //Instanciamos el objeto dv de tipo DeportistaView

                foreach(var e in lstEquipos)                    //Otro foreach anidado para recorrer la lista de Equipos
                {
                    if(d.EquipoId == e.Id)
                    {
                        dv.Equipo = e.Nombre;
                    }
                }
                dv.Id = d.Id;
                dv.Documento = d.Documento;
                dv.Nombres = d.Nombres;
                dv.Apellidos = d.Apellidos;

                    //Ya teniendo el objeto dv armado, lo agregamos a la lista DeportistasView
                DeportistasView.Add(dv);
            }    
        }
    }
}
