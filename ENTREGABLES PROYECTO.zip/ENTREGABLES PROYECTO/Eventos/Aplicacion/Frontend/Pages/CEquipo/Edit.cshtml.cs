using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEquipo
{
    public class EditModel : PageModel
    {
            //Como necesitamos transportar una lista de los Patrocinadores, entonces también necesitamos hacer uso de un repositorio de Patrocinadores _repoPat
        private readonly IREquipo _repoEquipo;
        private readonly IRPatrocinador _repoPat;

        [BindProperty]
        public Equipo Equipo {get; set;}

        public IEnumerable<Patrocinador> Patrocinadores {get; set;}

            //Constructor
        public EditModel(IREquipo repoEquipo, IRPatrocinador repoPat)
        {
            this._repoEquipo = repoEquipo;
            this._repoPat = repoPat;
        }

            //En este OnGet vamos a llenar la lista de Patrocinadores
        public ActionResult OnGet(int id)
        {
            Equipo = _repoEquipo.BuscarEquipo(id);
            Patrocinadores = this._repoPat.ListarPatrocinadores();

            if(Equipo == null)
            {
                ViewData["Error"] = "Equipo no encontrado";
                return Page();
            }
            else
            {
                return Page();
            }
        }

        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Patrocinadores = this._repoPat.ListarPatrocinadores(); //Llenamos la lista antes de que nos muestre los errores en el modelo
                return Page();
            }
            bool funciono = _repoEquipo.ActualizarEquipo(Equipo);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Patrocinadores = this._repoPat.ListarPatrocinadores();
                ViewData["Error"]="No se pueden registrar Equipos con el mismo nombre";  //En el AppContext se indicó Nombre como IsUnique 
                return Page();
            }
        }
    }
}
