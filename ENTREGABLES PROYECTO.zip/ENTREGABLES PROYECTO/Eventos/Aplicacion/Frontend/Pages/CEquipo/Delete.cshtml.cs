using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEquipo
{
    public class DeleteModel : PageModel
    {
            //Necesitamos dos repositorios, del Torneo y del Municipio
        private readonly IREquipo _repoEquipo;
        private readonly IRPatrocinador _repoPat;
        
            //Necesitamos dos propiedades vinculadas para hacer el transporte al front
        [BindProperty]
        public Equipo Equipo {get;set;}
        public Patrocinador Patrocinador {get;set;}

        public DeleteModel(IREquipo repoEquipo, IRPatrocinador repoPat)
        {
            this._repoEquipo = repoEquipo;
            this._repoPat = repoPat;
        }

        public ActionResult OnGet(int id)
        {
            Equipo = _repoEquipo.BuscarEquipo(id);
            Patrocinador = _repoPat.BuscarPatrocinador(Equipo.PatrocinadorId);
            if(Equipo == null)
            {
                ViewData["Error"]="Equipo no encontrado";
                return Page();
            }
            else
            {
                return Page();    
            }
        }

            //Ahora vamos a ejecutar la eliminación
        public ActionResult OnPost()
        {
            bool funciono = _repoEquipo.EliminarEquipo(Equipo.Id);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="El equipo no se pudo eliminar.";
                return Page();
            }
        }
    }
}
