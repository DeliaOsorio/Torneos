using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEquipo
{
    public class IndexModel : PageModel
    {
            //Atributos: dos objetos derivados de los repositorios, _repoEquipo y _repoPat
        private readonly IREquipo _repoEquipo;
            //Equipo depende de Patrocinador, para poderlos relacionar necesitamos tener también acceso a los Patrocinadores:
        private readonly IRPatrocinador _repoPat;
            //Con los Equipos y los Patrocinadores podemos armar los EquiposView el cual vamos a llevar al Index

        [BindProperty]
        public IEnumerable<Equipo> Equipos {get;set;}
       
        public List<EquipoView> EquiposView = new List<EquipoView>();

            //Métodos
            //Constructor
        public IndexModel(IREquipo repoEquipo, IRPatrocinador repoPat)
        {
            this._repoEquipo = repoEquipo;
            this._repoPat = repoPat;
        }

            //El OnGet devuelve al usuario una vista con los elementos que esta necesitando, y allí debemos ver el nombre de los Patrocinadores
        public void OnGet()
        {
                //Creamos una lista de Patrocinadores que la vamos a llamar lstPatrocinadores
            List<Patrocinador> lstPatrocinadores = _repoPat.ListarPatrocinadores1();
                //Tambien llenamos Equipos. Aquí tenemos todos los Equipos
            Equipos = _repoEquipo.ListarEquipos();
                //Con estas dos listas necesitamos llenar la lista EquiposView que es la que vamos a llevar a la vista:
            EquipoView ev = null;

            foreach(var e in Equipos)   //El foreach permite recorrer la lista de Equipos
            {
                ev = new EquipoView();     //Instanciamos el objeto ev de tipo EquipoView
                foreach(var p in lstPatrocinadores)     //otro foreach anidado para recorrer la lista de Municipios
                {
                    if(e.PatrocinadorId == p.Id)
                    {
                        ev.Patrocinador = p.Nombre;
                    }
                }
                ev.Id = e.Id;
                ev.Nombre = e.Nombre;
                ev.Deporte = e.Deporte;
                    //Ya teniendo el objeto ev armado, lo agregamos a la lista EquiposView
                EquiposView.Add(ev);
            }    
        }
    }
}
