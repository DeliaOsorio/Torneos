using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEquipo
{
    public class DetailsModel : PageModel
    {
        private readonly IREquipo _repoEquipo;
        private readonly IRPatrocinador _repoPat;

            //tenemos una propiedad vinculada que se va a llamar también Municipio.
            //Vincula la propiedad con el modelo para el momento de la captura. Para que tenga la propiedad de conectarse con los dataAnnotations
        [BindProperty]
        public Equipo Equipo {get; set;}
        public Patrocinador Patrocinador {get; set;}

            //Métodos
            //Constructor
        public DetailsModel (IREquipo repoEquipo, IRPatrocinador repoPat)
        {
            this._repoEquipo = repoEquipo;
            this._repoPat = repoPat;
        }

        public ActionResult OnGet(int id)
        {
            Equipo = _repoEquipo.BuscarEquipo(id);
            if(Equipo != null)
            {
                Patrocinador = _repoPat.BuscarPatrocinador(Equipo.PatrocinadorId);
                return Page();
            }
            else
            {
                ViewData["Error"]="Equipo no encontrado";
                return Page();
            }
        }
    }
}
