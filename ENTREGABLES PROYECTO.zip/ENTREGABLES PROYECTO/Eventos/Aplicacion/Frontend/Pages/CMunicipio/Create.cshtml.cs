using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CMunicipio
{
    public class CreateModel : PageModel
    {
        //Atributos
        private readonly IRMunicipio _repoMunicipio;

        [BindProperty] //Vincula la propiedad con el modelo para el momento de la captura. Para que tenga la propiedad de conectarse con los dataAnnotations
        public Municipio Municipio {get; set;}
        
        //Metodos
        //Constructor
        public CreateModel(IRMunicipio repoMunicipio)
        {
            this._repoMunicipio = repoMunicipio;
        }

        //Se encarga de mostrar información o mostrar nuevos formularios
        public ActionResult OnGet()
        {
            return Page(); //retorna la página que esta ligada a este modelo, es decir, la pagina Create
        }

        //Método que recibe la información desde un formulario
        public ActionResult OnPost()
        {
            if(!ModelState.IsValid) //Método que se encarga de validar la calidad de datos que estan ingresando en el formulario
            {
                return Page();
            }

            bool funciono = _repoMunicipio.CrearMunicipio(Municipio);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"] = "No se puede crear " + Municipio.Nombre + " porque ya existe";
                return Page();
            }
        }
    }
}
