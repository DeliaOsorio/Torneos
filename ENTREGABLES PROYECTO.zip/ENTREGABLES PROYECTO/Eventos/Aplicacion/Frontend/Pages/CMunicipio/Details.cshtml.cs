using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CMunicipio
{
    public class DetailsModel : PageModel
    {
        private readonly IRMunicipio _repoMunicipio;

            //tenemos una propiedad vinculada que se va a llamar también Municipio.
            //Vincula la propiedad con el modelo para el momento de la captura. Para que tenga la propiedad de conectarse con los dataAnnotations
        [BindProperty]
        public Municipio Municipio {get; set;}

            //Métodos
            //Constructor
        public DetailsModel (IRMunicipio repoMunicipio)
        {
            this._repoMunicipio = repoMunicipio;
        }

        public ActionResult OnGet(int id)
        {
            Municipio = _repoMunicipio.BuscarMunicipio(id);
            return Page();
        }
    }
}
