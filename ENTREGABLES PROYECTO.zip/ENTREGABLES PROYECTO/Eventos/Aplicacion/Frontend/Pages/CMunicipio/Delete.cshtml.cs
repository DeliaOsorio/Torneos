using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CMunicipio
{
    public class DeleteModel : PageModel
    {
            //Atributos
        private readonly IRMunicipio _repoMunicipio;

            //tenemos una propiedad vinculada que se va a llamar también Municipio.
            //Vincula la propiedad con el modelo para el momento de la captura. Para que tenga la propiedad de conectarse con los dataAnnotations
        [BindProperty]
        public Municipio Municipio {get; set;}

            //Metodos
            //Constructor
        public DeleteModel(IRMunicipio repoMunicipio)
        {
            this._repoMunicipio = repoMunicipio;
        }
        
            //El OnGet se encarga de colocar informacion en esa nueva vista y para eso hace una Búsqueda por Id, a diferencia del de Create.
            //tambien retorna algo por eso es de tipo ActionResult y le llega como parámetro un entero Id
            //El método OnGet solo adapta la vista, pero el que en realidad elimina es el metodo OnPost
        public ActionResult OnGet(int Id) 
        {
            //se llama al metodo buscar que se encuentra en RMunicipio de la Persistencia y se le envía el Id
            Municipio= _repoMunicipio.BuscarMunicipio(Id);
            if (Municipio==null)
            {
                ViewData["Error"]="Municipio no encontrado"; //este if lo estamos haciendo por estandar, porque en realidad el municipio si existe porque lo vemos en el formulario
                //El ViewData representa Datos para la Vista, es una forma fácil de transportar información entre el back (.cshtml.cs) y el front (.cshtml)
                return Page();
            }
            return Page();
        }

        //Eliminamos con el método OnPost y no recibe ningún parámetro
        public ActionResult OnPost()
        {
            bool funciono = _repoMunicipio.EliminarMunicipio(Municipio.Id); //Llamamos el metodo EliminarMunicipio de RMunicipio y le enviamos el Municipio del OnGet
            if (funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="No es posible eliminar el Municipio porque al menos un Torneo lo contiene (integridad referencial)";
                return Page();
            }
        }
    }
}
