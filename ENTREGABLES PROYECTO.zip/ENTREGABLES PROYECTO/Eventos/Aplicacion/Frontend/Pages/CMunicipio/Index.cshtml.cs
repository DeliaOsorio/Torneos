using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CMunicipio
{
    public class IndexModel : PageModel
    {
        //Llamando al repositorio RMunicipio podemos saber cuántos registros tiene la tabla
        //Atributos
        private readonly IRMunicipio _repoMunicipio;
        public IEnumerable<Municipio> Municipios {get;set;}

        //Metodos
        //Constructor
        public IndexModel(IRMunicipio repoMunicipio)
        {
            this._repoMunicipio=repoMunicipio;
        }

        //Llevar información a la página web vinculada, es decir a la pagina index.cshtml
        public void OnGet()
        {
            Municipios = _repoMunicipio.ListarMunicipios();
        }
    }
}
