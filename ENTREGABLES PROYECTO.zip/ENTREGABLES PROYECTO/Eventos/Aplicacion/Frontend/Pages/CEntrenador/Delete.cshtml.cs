using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEntrenador
{
    public class DeleteModel : PageModel
    {
            //Necesitamos dos repositorios, del Entrenador y del Equipo
        private readonly IREntrenador _repoEnt;
        private readonly IREquipo _repoEqu;
        
            //Necesitamos dos propiedades vinculadas para hacer el transporte al front
        [BindProperty]
        public Entrenador Entrenador {get;set;}
        public Equipo Equipo {get;set;}

        public DeleteModel(IREntrenador repoEnt, IREquipo repoEqu)
        {
            this._repoEnt = repoEnt;
            this._repoEqu = repoEqu;
        }
            //------------------------------------------------
        public ActionResult OnGet(int id)
        {
            Entrenador = _repoEnt.BuscarEntrenador(id);                 //Llenamos el objeto Entrenador buscando con el "Id del entrenador" que envian del front
            Equipo = _repoEqu.BuscarEquipo(Entrenador.EquipoId);        //Llenamos el objeto Equipo buscando en Equipos el Id que entrega "EquipoId de Entrenador"
            if(Entrenador == null)
            {
                ViewData["Error"]="Entrenador no encontrado";
                return Page();
            }
            else
            {
                return Page();    
            }
        }
            //-------------------------------------------------
            //Ahora vamos a ejecutar la eliminación
        public ActionResult OnPost()
        {
            bool funciono = _repoEnt.EliminarEntrenador(Entrenador.Id);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="El registro no se pudo eliminar";
                return Page();
            }
        }
    }
}
