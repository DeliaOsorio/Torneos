using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEntrenador
{
    public class DetailsModel : PageModel
    {
            //Vamos a manejar dos objetos, para el repositorio de Entrenador y el repositorio de Equipo: 
        private readonly IREntrenador _repoEnt;
        private readonly IREquipo _repoEqu;

            //Vamos a tener dos propiedades vinculadas:
        [BindProperty]
        public Entrenador Entrenador {get; set;}
        public Equipo Equipo {get;set;}         //De esta propiedad vinculada sacaremos el Nombre del equipo

            //Constructor
            //Se inicializan los dos objetos:
        public DetailsModel(IREntrenador repoEnt, IREquipo repoEqu)
        {
            this._repoEnt = repoEnt;
            this._repoEqu = repoEqu;
        }

            //El OnGet debe devolver la información tanto del municipio como del Torneo
        public ActionResult OnGet(int id)
        {
            Entrenador = _repoEnt.BuscarEntrenador(id);
            Equipo = _repoEqu.BuscarEquipo(Entrenador.EquipoId);

            if(Entrenador == null)
            {
                ViewData["Error"]="Entrenador no encontrado";
                return Page();
            }
            return Page();
        }
            //Los detalles no necesitan el método OnPost
    }
}
