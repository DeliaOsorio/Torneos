using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEntrenador
{
    public class IndexModel : PageModel
    {
            //Atributos: dos objetos derivados de los repositorios, _repoEquipo y _repoEntrenador
        private readonly IREquipo _repoEquipo;

            //Equipos depende de Entrenadores, para poderlos relacionar necesitamos tener también acceso a los Entrenadores:
        private readonly IREntrenador _repoEntrenador;
            //Con los Equipos y los Patrocinadores podemos armar los EquiposView el cual vamos a llevar al Index

        [BindProperty]
        public IEnumerable<Entrenador> Entrenadores {get;set;}
       
        public List<EntrenadorView> EntrenadoresView = new List<EntrenadorView>();

            //Métodos
            //Constructor
        public IndexModel(IREquipo repoEquipo, IREntrenador repoEntrenador)
        {
            this._repoEquipo = repoEquipo;
            this._repoEntrenador = repoEntrenador;
        }

            //El OnGet devuelve al usuario una vista con los elementos que esta necesitando, y allí debemos ver el nombre de los Equipos
        public void OnGet()
        {
                //Creamos una lista de Equipos que la vamos a llamar lstEquipos
            List<Equipo> lstEquipos = _repoEquipo.ListarEquipos1();
                
                //Tambien llenamos Entrenadores. Aquí tenemos todos los Entrenadores
            Entrenadores = _repoEntrenador.ListarEntrenadores();
                
                //Con estas dos listas necesitamos llenar la lista EntrenadoresView que es la que vamos a llevar a la vista:
            EntrenadorView ev = null;

            foreach(var e in Entrenadores)   //El foreach permite recorrer la lista de Entrenadores
            {
                ev = new EntrenadorView();     //Instanciamos el objeto ev de tipo EntrenadorView
                foreach(var q in lstEquipos)     //otro foreach anidado para recorrer la lista de Equipos
                {
                    if(e.EquipoId == q.Id)
                    {
                        ev.Equipo = q.Nombre;
                    }
                }
                ev.Id = e.Id;
                ev.Documento = e.Documento;
                ev.Nombres = e.Nombres;
                ev.Apellidos = e.Apellidos;
                
                    //Ya teniendo el objeto ev armado, lo agregamos a la lista EquiposView
                EntrenadoresView.Add(ev);
            }    
        }
    }
}
