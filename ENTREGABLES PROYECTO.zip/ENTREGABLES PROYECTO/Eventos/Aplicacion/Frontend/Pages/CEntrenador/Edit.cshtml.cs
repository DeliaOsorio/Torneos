using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEntrenador
{
    public class EditModel : PageModel
    {
        private readonly IREntrenador _repoEnt;
        private readonly IREquipo _repoEqu;

        [BindProperty]
        public Entrenador Entrenador {get;set;}            //La propiedad Entrenador
        public IEnumerable<Equipo> Equipos {get;set;}     //Una lista de Equipos

            //Constructor
        public EditModel(IREntrenador repoEnt, IREquipo repoEqu)
        {
            this._repoEnt = repoEnt;
            this._repoEqu = repoEqu;
        }

        public ActionResult OnGet(int id)
        {
            Entrenador = _repoEnt.BuscarEntrenador(id);
            Equipos = _repoEqu.ListarEquipos();       //IEnumerable

            if(Entrenador == null)
            {
                ViewData["Error"] = "Entrenador no encontrado";
                return Page();
            }
            else
            {
                return Page();
            }
        }   //Hasta aquí muestra la información en pantalla

        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Equipos = _repoEqu.ListarEquipos();   //Que llene nuevamente la lista de Equipos, para que no genere errores
                return Page();
            }

            bool funciono = _repoEnt.ActualizarEntrenador(Entrenador);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Equipos = _repoEqu.ListarEquipos();   //Que llene nuevamente la lista de Equipos, para que no genere errores
                //ViewData["Error"]="Ya existe un Entrenador con el documento " + Entrenador.Documento;   //En el AppContext se indicó Documento como IsUnique
                ViewData["Error"]="No puede duplicar los valores de documento y/o equipo";
                return Page();
            }
        }
    }
}
