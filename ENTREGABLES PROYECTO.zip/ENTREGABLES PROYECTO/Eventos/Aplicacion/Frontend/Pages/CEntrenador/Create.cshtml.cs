using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEntrenador
{
    public class CreateModel : PageModel
    {
            //Como necesitamos transportar una lista de los Equipos, entonces también necesitamos hacer uso de un repositorio de Equipos _repoEquipo
        private readonly IREquipo _repoEquipo;
        private readonly IREntrenador _repoEntrenador;

        [BindProperty]
        public Entrenador Entrenador {get; set;}

        public IEnumerable<Equipo> Equipos {get; set;}

            //Constructor
        public CreateModel(IREquipo repoEquipo, IREntrenador repoEntrenador)
        {
            this._repoEquipo = repoEquipo;
            this._repoEntrenador = repoEntrenador;
        }

            //En este OnGet vamos a llenar la lista de Equipos
        public ActionResult OnGet()
        {
            Equipos = this._repoEquipo.ListarEquipos();
            return Page();
        }

        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Equipos = this._repoEquipo.ListarEquipos(); //Llenamos la lista antes de que nos muestre los errores en el modelo
                return Page();
            }

            bool funciono = _repoEntrenador.CrearEntrenador(Entrenador);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Equipos = this._repoEquipo.ListarEquipos();
                ViewData["Error"]="Documento " + Entrenador.Documento + " repetido. No se puede hacer el registro.";
                return Page();
            }
        }
    }
}
