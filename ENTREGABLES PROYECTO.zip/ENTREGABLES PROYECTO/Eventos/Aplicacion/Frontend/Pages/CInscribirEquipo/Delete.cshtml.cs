using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CInscribirEquipo
{
    public class DeleteModel : PageModel
    {
        private readonly IREquipo _repoEquipo;
        private readonly IRTorneo _repoTor;
        private readonly IRTorneoEquipo _repoTorEqu;

        [BindProperty]
            //TorneoEquipo es el que va a hacer la transacción de eliminar en la BD:
        public TorneoEquipo TorneoEquipo {get; set;}
        public Equipo Equipo {get; set;}
        public Torneo Torneo {get; set;}
          
            //Constructor
        public DeleteModel(IREquipo repoEquipo, IRTorneo repoTor, IRTorneoEquipo repoTorEqu)
        {
            this._repoEquipo = repoEquipo;
            this._repoTor = repoTor;
            this._repoTorEqu = repoTorEqu;
        }

        public ActionResult OnGet(int idT, int idE)
        {
            TorneoEquipo = _repoTorEqu.BuscarTorneoEquipo(idT, idE);
            Torneo = _repoTor.BuscarTorneo(idT);
            Equipo = _repoEquipo.BuscarEquipo(idE);

            if(TorneoEquipo != null)
            {
                return Page();
            }
            else 
            {
                ViewData["Error"] = "Registro no encontrado";
                return Page();
            }
        }

        public ActionResult OnPost()
        {
            bool funciono = _repoTorEqu.EliminarTorneoEquipo(TorneoEquipo.TorneoId, TorneoEquipo.EquipoId);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"] = "El equipo no puede ser retirado del torneo";
                return Page();
            }
        }
    }
}
