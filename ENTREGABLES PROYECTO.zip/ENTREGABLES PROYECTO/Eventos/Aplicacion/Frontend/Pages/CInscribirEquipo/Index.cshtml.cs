using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CInscribirEquipo
{
    public class IndexModel : PageModel
    {
        private readonly IRTorneoEquipo _repoTorEqu;
        private readonly IRTorneo _repoTor;
        private readonly IREquipo _repoEquipo;

        [BindProperty]
        public IEnumerable<TorneoEquipo> TorneoEquipos {get;set;}

        public List<TorneoEquipoView> TorneosEquiposV = new List<TorneoEquipoView>();  //Esta lista transporta la información hasta este Index

            //Constructor
        public IndexModel(IRTorneoEquipo repoTorEqu, IRTorneo repoTor, IREquipo repoEquipo)
        {
            this._repoEquipo = repoEquipo;
            this._repoTor = repoTor;
            this._repoTorEqu = repoTorEqu;
        }

        public void OnGet()
        {
                //Necesitamos las dos listas
            List<Torneo> lstTorneos = _repoTor.ListarTorneos1();
            List<Equipo> lstEquipos = _repoEquipo.ListarEquipos1();
            TorneoEquipos = _repoTorEqu.ListarTorneoEquipos();

            TorneoEquipoView tev = null;

            foreach (var te in TorneoEquipos)
            {
                tev = new TorneoEquipoView();

                foreach (var t in lstTorneos)
                {
                    if(te.TorneoId == t.Id)
                    {
                        tev.Torneo = t.Nombre;
                        tev.TorneoId = t.Id;
                    }
                }

                foreach (var e in lstEquipos)
                {
                    if(te.EquipoId == e.Id)
                    {
                        tev.Equipo = e.Nombre;
                        tev.EquipoId = e.Id;
                    }
                }
                TorneosEquiposV.Add(tev);
            }
        }
    }
}
