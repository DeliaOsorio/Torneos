using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CInscribirEquipo
{
    public class CreateModel : PageModel
    {
        private readonly IRTorneo _repoTor;
        private readonly IREquipo _repoEquipo;
        private readonly IRTorneoEquipo _repoTorEqu;

        [BindProperty]
            //Necesitamos una lista de Equipos, una lista de Torneos y un objeto de TorneoEquipo
        public TorneoEquipo TorneoEquipo {get; set;}
        public IEnumerable<Torneo> Torneos {get; set;}
        public IEnumerable<Equipo> Equipos {get; set;}

            //Constructor
        public CreateModel (IREquipo repoEquipo, IRTorneo repoTor, IRTorneoEquipo repoTorEqu)
        {
            this._repoEquipo = repoEquipo;
            this._repoTor = repoTor;
            this._repoTorEqu = repoTorEqu;
        }     

        public ActionResult OnGet()
        {
            Torneos = _repoTor.ListarTorneos();
            Equipos = _repoEquipo.ListarEquipos();

            if(Torneos != null && Equipos != null)
            {
                return Page();
            }
            else
            {
                ViewData["Error"]= "No hay equipos o torneos suficvientes para realizar esta operación";
                return Page();
            }
        }
        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Torneos = _repoTor.ListarTorneos();
                Equipos = _repoEquipo.ListarEquipos();
                return Page();
            }
            
            bool funciono = _repoTorEqu.CrearTorneoEquipo(TorneoEquipo);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Torneos = _repoTor.ListarTorneos();
                Equipos = _repoEquipo.ListarEquipos();
                ViewData["Error"] = "El equipo ya se encuentra registrado en este torneo";
                return Page();
            }
        }
    }
}
