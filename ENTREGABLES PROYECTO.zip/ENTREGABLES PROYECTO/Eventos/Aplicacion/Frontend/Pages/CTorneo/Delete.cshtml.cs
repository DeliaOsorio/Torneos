using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CTorneo
{
    public class DeleteModel : PageModel
    {
            //Necesitamos dos repositorios, del Torneo y del Municipio
        private readonly IRTorneo _repoTor;
        private readonly IRMunicipio _repoMun;
        
            //Necesitamos dos propiedades vinculadas para hacer el transporte al front
        [BindProperty]
        public Torneo Torneo {get;set;}
        public Municipio Municipio {get;set;}

        public DeleteModel(IRTorneo repoTor, IRMunicipio repoMun)
        {
            this._repoMun = repoMun;
            this._repoTor = repoTor;
        }

        public ActionResult OnGet(int id)
        {
            Torneo = _repoTor.BuscarTorneo(id);
            Municipio = _repoMun.BuscarMunicipio(Torneo.MunicipioId);
            if(Torneo == null)
            {
                ViewData["Error"]="Torneo no encontrado";
                return Page();
            }
            else
            {
                return Page();    
            }
        }

            //Ahora vamos a ejecutar la eliminación
        public ActionResult OnPost()
        {
            bool funciono = _repoTor.EliminarTorneo(Torneo.Id);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="El registro no se pudo eliminar";
                return Page();
            }
        }
    }
}
