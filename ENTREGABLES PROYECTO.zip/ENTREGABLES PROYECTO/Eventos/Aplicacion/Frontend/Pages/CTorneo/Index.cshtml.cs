using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CTorneo
{
    public class IndexModel : PageModel
    {
            //Atributos: dos objetos derivados de los repositorios, _repoTor y _repoMun
        private readonly IRTorneo _repoTor;
            //Torneo depende de Municipio, para poderlos relacionar necesitamos tener también acceso a los municipios:
        private readonly IRMunicipio _repoMun;
            //Con los Torneos y los Municipios podemos armar los TorneoView el cual vamos a llevar al Index

        [BindProperty]
        public IEnumerable<Torneo> Torneos {get;set;}
       
        public List<TorneoView> TorneosView = new List<TorneoView>();

            //Métodos
            //Constructor
        public IndexModel(IRTorneo repoTor, IRMunicipio repoMun)
        {
            this._repoTor = repoTor;
            this._repoMun = repoMun;
        }

            //El OnGet devuelve al usuario una vista con los elementos que esta necesitando, y allí debemos ver el nombre de los Municipios
        public void OnGet()
        {
                //Creamos una lista de Municipios que la vamos a llamar lstMunicipios
            List<Municipio> lstMunicipios = _repoMun.ListarMunicipios1();
                //Tambien llenamos Torneos. Aquí tenemos todos los Torneos
            Torneos = _repoTor.ListarTorneos();
                //Con estas dos listas necesitamos llenar la lista TorneoView que es la que vamos a llevar a la vista:
            TorneoView tv = null;

            foreach(var t in Torneos)   //El foreach permite recorrer la lista de torneos
            {
                tv = new TorneoView();     //Instanciamos el objeto tv de tipo TorneoView
                foreach(var m in lstMunicipios)     //otro foreach anidado para recorrer la lista de Municipios
                {
                    if(t.MunicipioId == m.Id)
                    {
                        tv.Municipio = m.Nombre;
                    }
                }
                tv.Id = t.Id;
                tv.Nombre = t.Nombre;
                tv.Categoria = t.Categoria;
                tv.Deporte = t.Deporte;
                tv.FechaInicial = t.FechaInicial;
                tv.FechaFinal = t.FechaFinal;
                tv.CantEquipos = t.CantEquipos;
                    //Ya teniendo el objeto tv armado, lo agregamos a la lista TorneosView
                TorneosView.Add(tv);
            }    
        }
    }
}
