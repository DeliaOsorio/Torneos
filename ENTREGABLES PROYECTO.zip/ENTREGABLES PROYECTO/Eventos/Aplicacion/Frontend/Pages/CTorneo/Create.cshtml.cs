using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CTorneo
{
    public class CreateModel : PageModel
    {
            //Como necesitamos transportar una lista de los Municipios, entonces también necesitamos hacer uso de un repositorio de Municipios _repoMun
        private readonly IRTorneo _repoTor;
        private readonly IRMunicipio _repoMun;

        [BindProperty]
        public Torneo Torneo {get; set;}
        public IEnumerable<Municipio> Municipios {get; set;}

            //Constructor

        public CreateModel(IRTorneo repoTor, IRMunicipio repoMun)
        {
            this._repoMun = repoMun;
            this._repoTor = repoTor;
        }

            //En este OnGet vamos a llenar la lista de Municipios
        public ActionResult OnGet()
        {
            Municipios = this._repoMun.ListarMunicipios();
            return Page();
        }

        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Municipios = this._repoMun.ListarMunicipios(); //Llenamos la lista antes de que nos muestre los errores en el modelo
                return Page();
            }
            bool funciono = _repoTor.CrearTorneo(Torneo);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Municipios = this._repoMun.ListarMunicipios();
                ViewData["Error"]="No se pueden registrar torneos con el mismo nombre";
                return Page();
            }
        }
    }
}
