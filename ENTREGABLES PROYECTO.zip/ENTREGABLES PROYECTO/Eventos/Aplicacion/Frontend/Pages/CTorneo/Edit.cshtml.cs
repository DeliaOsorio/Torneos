using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CTorneo
{
    public class EditModel : PageModel
    {
        private readonly IRTorneo _repoTor;
        private readonly IRMunicipio _repoMun;

        [BindProperty]
        public Torneo Torneo {get;set;}
        public IEnumerable<Municipio> Municipios {get;set;}

            //Constructor
        public EditModel(IRTorneo repoTor, IRMunicipio repoMun)
        {
            this._repoMun = repoMun;
            this._repoTor = repoTor;
        }

        public ActionResult OnGet(int id)
        {
            Torneo = _repoTor.BuscarTorneo(id);
            Municipios = _repoMun.ListarMunicipios();   //IEnumerable

            if(Torneo == null)
            {
                ViewData["Error"] = "Torneo no encontrado";
                return Page();
            }
            else
            {
                return Page();
            }
        }   //Hasta aquí muestra la información en pantalla

        public ActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                Municipios = _repoMun.ListarMunicipios();   //Que llene la lista,para que no genere errores
                return Page();
            }

            bool funciono = _repoTor.ActualizarTorneo(Torneo);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Municipios = _repoMun.ListarMunicipios();   //Que llene la lista,para que no genere errores
                ViewData["Error"]="Ya existe un Torneo con el nombre " + Torneo.Nombre;         //En el AppContext se indicó Nombre como IsUnique
                return Page();
            }
        }
    }
}
