using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CTorneo
{
    public class DetailsModel : PageModel
    {
            //Vamos a manejar dos objetos, para el repositorio de Torneo y el repositorio de Municipio: 
        private readonly IRTorneo _repoTor;
        private readonly IRMunicipio _repoMun;

            //Vamos a tener dos propiedades vinculadas:
        [BindProperty]
        public Torneo Torneo {get; set;}
        public Municipio Municipio {get;set;}

            //Constructor
            //Se inicializan los dos objetos:
        public DetailsModel(IRTorneo repoTor, IRMunicipio repoMun)
        {
            this._repoTor = repoTor;
            this._repoMun = repoMun;
        }

            //El OnGet debe devolver la información tanto del municipio como del Torneo
        public ActionResult OnGet(int id)
        {
            Torneo = _repoTor.BuscarTorneo(id);
            Municipio = _repoMun.BuscarMunicipio(Torneo.MunicipioId);

            if(Torneo == null)
            {
                ViewData["Error"]="Torneo no encontrado";
                return Page();
            }
            return Page();
        }
            //Los detalles no necesitan el método OnPost
    }
}
