using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
        //DataAnnotation para indicar que un campo es único, podemos hacerlo así: [Index(nameof(Documento), IsUnique = True)]
        //o con el API fluente del AppContext
    public class Patrocinador
    {
            //Propiedades

        public int Id {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(15,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(9,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[0-9-]*", ErrorMessage="Solo se permiten números y el guión (-)")]
        public string Documento {get;set;}
        
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(40,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú0-9 ]*", ErrorMessage="Solo se permiten letras y números")]
        public string Nombre {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            //[RegularExpression("[A-Za-zá-ú ]*", ErrorMessage="Solo se permiten letras")]
            [Display(Name="Tipo de Persona")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public string TipoPersona {get;set;}

            [MaxLength(40,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [Display(Name="Dirección")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public string Direccion {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [RegularExpression("[0-9]*", ErrorMessage="El teléfono solo debe contener números")]
            [Display(Name="Teléfono")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public string Telefono {get;set;}

            //Propiedad navigacional para la relación con Equipo (1 Patrocinador patrocina 1 o muchos Equipos;
            //1 Equipo es patrocinado por 1 Patrocinador), es una lista, entonces no se delimita MaxLength ni MinLength
        public List<Equipo> Equipos {get;set;}
    }
}