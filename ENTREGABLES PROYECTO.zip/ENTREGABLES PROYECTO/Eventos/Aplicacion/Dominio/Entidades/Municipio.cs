using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
        //DataAnnotation para indicar que un campo es único, podemos hacerlo así: [Index(nameof(Nombre), IsUnique = True)]
        //o con los API fluentes del AppContext
    public class Municipio
    {
         /*
            //atributos
            private int Id;
            private string Nombre;

            //Metodos
            public Municipio()
            {}
            public void setId(int id)
            {
                this.Id=id;
            }
            public int getId()
            {
                return this.Id;
            }
            public void setNombre(string nombre)
            {
                this.Nombre=nombre;
            }
            public string getNombre()
            {
                return this.Nombre;
            }
            */

            //Propiedades

        public int Id {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(30,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(4,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú ]*", ErrorMessage="Solo se permiten letras")]
        public string Nombre {get;set;}

            //Relación con Torneo (1 Municipio realiza muchos Tormeos, 1 Torneo se realiza en 1 Municipio), 
            //propiedad navigacional, es una lista, entonces no se delimita MaxLength ni MinLength
        public List<Torneo> Torneos {get;set;}
    }
}