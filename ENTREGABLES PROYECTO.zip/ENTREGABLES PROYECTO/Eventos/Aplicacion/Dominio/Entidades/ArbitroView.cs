using System;
using System.Collections.Generic; //para que pueda usar las listas

namespace Dominio
{
    public class ArbitroView
    {
        //Propiedades
        public int Id {get;set;}

        public string Documento {get;set;}
        
        public string Nombres {get;set;}

        public string Apellidos {get;set;}

        public string Deporte {get;set;}

        public string RH {get;set;}

            //La Vista no maneja Foráneas, es decir, no maneja relación con ninguna otra tabla, 
            //no va  tener el public int TorneoId {get;set;}
            //Trabajaremos con un campo que va a contener el Nombre del Torneo, así: 
        public string Torneo {get;set;}

            //no va  tener el public int ColegioId {get;set;}
            //Trabajaremos con un campo que va a contener el Nombre del Colegio, así: 
        public string Colegio {get;set;}
    }
}