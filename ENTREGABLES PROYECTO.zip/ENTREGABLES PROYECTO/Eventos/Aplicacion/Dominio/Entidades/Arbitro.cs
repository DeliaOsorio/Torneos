using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class Arbitro
    {
        //Propiedades
        public int Id {get;set;}

        [Required(ErrorMessage="El campo {0} es obligatorio")]
        [MaxLength(15,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
        [MinLength(7,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string Documento {get;set;}
        
        [Required(ErrorMessage="El campo {0} es obligatorio")]
        [MaxLength(20,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
        [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string Nombres {get;set;}

        [Required(ErrorMessage="El campo {0} es obligatorio")]
        [MaxLength(20,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
        [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string Apellidos {get;set;}

        [Required(ErrorMessage="El campo {0} es obligatorio")]
        [MaxLength(20,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
        [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string Deporte {get;set;}

        [Required(ErrorMessage="El campo {0} es obligatorio")]
        [MaxLength(3,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
        [MinLength(2,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string RH {get;set;}

        //Llave foranea para la relación con Equipo
        [Required(ErrorMessage="El campo {0} es obligatorio")]
        [Display(Name="Torneo")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public int TorneoId {get;set;}

        //Llave foranea para la relación con Colegio
        [Required(ErrorMessage="El campo {0} es obligatorio")]
        [Display(Name="Colegio")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public int ColegioId {get;set;}

            //Propiedad navigacional para complementar la relacion con Colegio por si se necesita
            //Agregamos propiedad navigacional que indica la clase base de la llave foránea, 
            //para poder usar el API fluente para eliminación en casacada:
        public Colegio Colegio {get;set;}

        public Torneo Torneo {get;set;}
        
    }
}