using System;
using System.Collections.Generic; //para que pueda usar las listas

namespace Dominio
{
    public class EntrenadorView
    {
            //Propiedades

        public int Id {get;set;}

        public string Documento {get;set;}
        
        public string Nombres {get;set;}

        public string Apellidos {get;set;}

        public string Genero {get;set;}

        public string Deporte {get;set;}

        public string RH {get;set;}

        public DateTime FechaNacimiento {get;set;}

        public string Correo {get;set;}

        public string Celular {get;set;}

            //La Vista no maneja Foráneas, es decir, no maneja relación con ningubna otra tabla, 
            //no va  tener el public int EquipoId {get;set;}
            //Trabajaremos con un campo que va a contener el Nombre del Equipo, así: 
        public string Equipo {get;set;}        
    }
}