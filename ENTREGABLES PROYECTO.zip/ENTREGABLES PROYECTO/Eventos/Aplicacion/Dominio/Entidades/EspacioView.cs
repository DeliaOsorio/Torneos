using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class EspacioView
    {
        //Propiedades
        public int Id {get;set;}
        
        public string Nombre {get;set;}

        public string Disciplina {get;set;}

        public int Espectadores {get;set;}

           //La llave foranea para la relación con Escenario se convierte en string Escenario
        public string Escenario {get;set;}      
    }
}