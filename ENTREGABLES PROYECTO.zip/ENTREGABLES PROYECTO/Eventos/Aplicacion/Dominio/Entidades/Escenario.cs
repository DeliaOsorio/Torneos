using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class Escenario
    {
        //Propiedades
        //[key] esta notacion es para indicar que es primaria, pero el framework actualmente esta reconociendo Id como primaria y no necesitamos usarlo
        public int Id {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(30,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú0-9 ]*", ErrorMessage="Solo se permiten letras y números")]
        public string Nombre {get;set;}

            [MaxLength(30,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [Display(Name="Dirección")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public string Direccion {get;set;}
      
            //Llave foranea para la relación con Torneo
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [Display(Name="Torneo")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public int TorneoId {get;set;}
        
            //Relacion con Espacio (1 Escenario tiene 1 o muchos Espacios, 1 Espacio pertenece a 1 Escenario), propiedad navigaciona, es una lista, entonces no se delimita max ni min
        public List<Espacio> Espacio {get;set;}

            //Propiedad navigacional para complementar la relacion con Torneo por si se necesita
        public Torneo Torneo {get;set;}
    }
}