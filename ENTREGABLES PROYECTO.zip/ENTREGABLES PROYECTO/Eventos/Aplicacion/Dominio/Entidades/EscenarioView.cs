using System;

namespace Dominio
{
    public class EscenarioView
    {
        public int Id{set;get;}
        public string Nombre{set;get;}
        public string Direccion {set;get;}
        public string Torneo{set;get;}
        
    }
}