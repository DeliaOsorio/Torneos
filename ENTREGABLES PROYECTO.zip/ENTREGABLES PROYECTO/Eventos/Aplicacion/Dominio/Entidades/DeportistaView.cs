using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class DeportistaView
    {
        //Propiedades

        public int Id {get;set;}

        public string Documento {get;set;}
        
        public string Nombres {get;set;}

        public string Apellidos {get;set;}

        public string Deporte {get;set;}

        public string RH {get;set;}

        public DateTime FechaNacimiento {get;set;}

        public string Genero {get;set;}

        public string Correo {get;set;}

        public string Celular {get;set;}
        
             //Llave foranea para la relación con Equipo, ahora es string
            //[Required(ErrorMessage="El campo {0} es obligatorio")]
            //[Display(Name="Equipo")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public string Equipo {get;set;}
        
    }
}