using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class TorneoEquipo
    {
            //Propiedades

            //Vamos a manejar una llave primaria compuesta con dos campos, EquipoId y TorneoId.
            //Para que eso quede registrado, vamos al AppContext y sobreescribimos un método llamado OnModelCreating

            //Llave foranea para la relación con Equipo
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [Display(Name="Equipo")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public int EquipoId {get;set;}

            //Llave foranea para la relación con Torneo
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [Display(Name="Torneo")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public int TorneoId {get;set;}

            //propiedades navigacionales. Relacion muchos a muchos (tabla detalle)
        
        public Equipo Equipo {get;set;}
        
        public Torneo Torneo {get;set;}

    }
}