using System;
using System.Collections.Generic; //para que pueda usar las listas

namespace Dominio
{
        //La Vista no maneja DataAnnotations, ni propiedades navigacionales, y tampoco foráneas.

    public class EquipoView
    {
            //Propiedades
  
        public int Id {get;set;}

        public string Nombre {get;set;}

        public string Deporte {get;set;}
    
        public Entrenador Tecnico {get;set;}
       
            //La Vista no maneja Foráneas, es decir, no va  tener el public int PatrocinadorId {get;set;}
            //Trabajaremos con un campo que va a contener el Nombre del Parocinador, así: 
        public string Patrocinador {get;set;}
    }
}