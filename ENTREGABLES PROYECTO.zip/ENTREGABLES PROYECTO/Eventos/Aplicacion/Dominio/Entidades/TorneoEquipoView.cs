using System;
using System.Collections.Generic; //para que pueda usar las listas

namespace Dominio
{
    public class TorneoEquipoView
    {        
        public int EquipoId {get;set;}  //Llave foranea para la relación con Equipo  
        public int TorneoId {get;set;}  //Llave foranea para la relación con Torneo

            //propiedades navigacionales. Relacion muchos a muchos (tabla detalle) 
            //ya no van a ser objetos sino string
        public string Equipo {get;set;}
        public string Torneo {get;set;}
    }
}