using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class Colegio
    {
            //Propiedades
        public int Id {get;set;}

            [Required(ErrorMessage="El campo  es obligatorio")]
            [MaxLength(15,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(9,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[0-9-]*", ErrorMessage="Solo se permiten números y el guión (-)")]
        public string Nit {get;set;}
        
            [Required(ErrorMessage="El campo Nombre es obligatorio")]
            [MaxLength(50,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [Display(Name="Razón Social")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public string RazonSocial {get;set;}
        
            [MaxLength(30,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [Display(Name="Dirección")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public string Direccion {get;set;}
        
            [Required(ErrorMessage="El campo Nombre es obligatorio")]
            [MaxLength(40,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(10,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string Correo {get;set;}

            //Relacion con Arbitro (1 Colegio instruye muchos Arbitros, 1 Arbitro es instruido por 1 Colegio), propiedad navigacional, es una lista, entonces no se delimita max ni min
        public List<Arbitro> Arbitros {get;set;}
    }
}