using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class Torneo
    {
            //Propiedades
            //[key] esta notacion es para indicar que es primaria, pero el framework actualmente esta reconociendo Id como primaria y no necesitamos usarlo
        
        public int Id {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(30,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(4,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú0-9 ]*", ErrorMessage="Solo se permiten letras y números")]
        public string Nombre {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(20,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(4,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú0-9 ]*", ErrorMessage="Solo se permiten letras y números")]
            [Display(Name="Categoría")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public string Categoria {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(15,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(4,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú0-9 ]*", ErrorMessage="Solo se permiten letras y números")]
        public string Deporte {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [DataType(DataType.Date)]
            [Display(Name="Fecha Inicial")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public DateTime FechaInicial {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [DataType(DataType.Date)]
            [Display(Name="Fecha Final")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public DateTime FechaFinal {get;set;}
        
            [Range(0,30,ErrorMessage="El torneo admite máximo 30 equipos")]
            [Display(Name="Cantidad de Equipos")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public int CantEquipos {get;set;}

            //Llave foranea para la relación con Municipio
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [Display(Name="Municipio")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public int MunicipioId {get;set;}
        
            //Relacion con TorneoEquipo (1 Torneo esta en muchos TorneoEquipos, 1 TorneoEquipo registra a 1 Torneo), propiedad navigaciona, es una lista, entonces no se delimita max ni min
        public List<TorneoEquipo> TorneoEquipos {get;set;}

            //Relacion con Arbitro (1 Torneo tiene muchos Arbitros, 1 Arbitro participa 1 Torneo), propiedad navigaciona, es una lista, entonces no se delimita max ni min
        public List<Arbitro> Arbitros {get;set;}

            //Relacion con Escenario (1 Torneo tiene muchos Escenarios, 1 Escenario pertenece a 1 Torneo), propiedad navigaciona, es una lista, entonces no se delimita max ni min
        public List<Escenario> Escenarios {get;set;}

    }
}