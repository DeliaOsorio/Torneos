using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class Equipo
    {
            //Propiedades
            //[key] esta notación es para indicar que es llave primaria (solo se lpuede aplicar a un campo, si son mas de uno se debe definir por API afluente), pero el framework actualmente esta reconociendo Id como primaria y no necesitamos usarlo
        public int Id {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(30,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(4,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú0-9 ]*", ErrorMessage="Solo se permiten letras y números")]
        public string Nombre {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(15,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(4,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú0-9 ]*", ErrorMessage="Solo se permiten letras y numeros")]
        public string Deporte {get;set;}
    
            //relacion 1 a 1 con el Entrenador. Propiedad navigacional para la relación con el Entrenador
        public Entrenador Tecnico {get;set;}
       
            //Llave foránea para la relación con Patrocinador
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [Display(Name="Patrocinador")]  //DataAnnotation para mostrar en la vista un nombre más entendible
        public int PatrocinadorId {get;set;}

            //Agregamos propiedad navigacional que indica la clase base de la llave foránea, 
            //para poder usar el API fluente para eliminación en casacada:
        public Patrocinador Patrocinador {get;set;}
        
            //Relación con TorneoEquipo (1 Equipo participa en muchos TorneoEquipo, 1 TorneoEquipo registra a 1 Equipo), propiedad navigaciona, es una lista
        public List<TorneoEquipo> TorneoEquipos {get;set;}
        
            //Relación con Deportista (1 Equipo tiene 1 o muchos Deportistas, 1 Deportista pertenece a 1 Equipo), propiedad navigacional, es una lista
        public List<Deportista>Deportistas{get;set;}
        

    }
}