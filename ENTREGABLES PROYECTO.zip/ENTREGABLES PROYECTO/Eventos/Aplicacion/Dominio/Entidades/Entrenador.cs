using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class Entrenador
    {
            //Propiedades
            //[key] esta notación es para indicar que es PK (solo se puede aplicar a un campo, si son mas de uno se debe definir por API afluente), pero el framework actualmente esta reconociendo Id como primaria y no necesitamos usarlo
        public int Id {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(15,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(7,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[0-9]*", ErrorMessage="Solo se penmiten números")]
        public string Documento {get;set;}
        
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(20,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú ]*", ErrorMessage="Solo se permiten letras")]
        public string Nombres {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(20,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú ]*", ErrorMessage="Solo se permiten letras")]
        public string Apellidos {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            //Usaremos listas desplegables para limitar la información que el usuario digita, por eso no usaremos MaxLenghth ni MinLength
            [Display(Name="Género")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public string Genero {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(15,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú0-9 ]*", ErrorMessage="Solo se permiten letras y números")]
        public string Deporte {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            //[MaxLength(3,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            //[MinLength(2,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string RH {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [DataType(DataType.Date)]
            [Display(Name="Fecha de Nacimiento")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public DateTime FechaNacimiento {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [DataType(DataType.EmailAddress)]
        public string Correo {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [Range(3000000000,3509999999,ErrorMessage="Ingrese un número de teléfono celular válido")]
        public string Celular {get;set;}

            //Llave foránea para la relación con Equipo
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [Display(Name="Equipo")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public int EquipoId {get;set;}        
    }
}