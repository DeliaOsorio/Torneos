using System;
using System.Collections.Generic; //para que pueda usar las listas

namespace Dominio
{
    public class TorneoView
    {
        public int Id {get;set;}
        public string Nombre {get;set;}
        public string Categoria {get;set;}
        public string Deporte {get;set;}
        public DateTime FechaInicial {get;set;}
        public DateTime FechaFinal {get;set;}
        public int CantEquipos {get;set;}

        //TorneoView no maneja foránea de MunicipioId, sino un campo Municipio que es string
        //que representa el nombre del municipio que es lo que se le va a mostrar al usuario

        public string Municipio {get;set;}
        
        //TorneoView no maneja relación con TorneoEquipos ni con ninguna otra tabla
    }
}