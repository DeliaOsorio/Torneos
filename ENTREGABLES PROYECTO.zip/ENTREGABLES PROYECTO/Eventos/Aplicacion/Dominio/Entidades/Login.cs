using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class Login
    {
            //Propiedades
        
        public int Id {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
        public string Usuario {get; set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(12,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(6,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú0-9]*", ErrorMessage="Solo se permiten letras y números")]
            [DataType(DataType.Password)]
        public string Password {get; set;}
    }
}