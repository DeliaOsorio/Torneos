using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class Deportista
    {
        //Propiedades
        public int Id {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(15,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(7,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string Documento {get;set;}
        
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(20,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string Nombres {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(20,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string Apellidos {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(20,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string Deporte {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(3,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(2,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
        public string RH {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [DataType(DataType.Date)]
            [Display(Name="Fecha de Nacimiento")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public DateTime FechaNacimiento {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(14,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [Display(Name="Género")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public string Genero {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [DataType(DataType.EmailAddress)]
        public string Correo {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [Range(3000000000,3299999999,ErrorMessage="Ingrese un número de teléfono celular válido")]
        public string Celular {get;set;}

            //Llave foranea para la relación con Equipo
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [Display(Name="Equipo")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public int EquipoId {get;set;}

            // Agregamos propiedad navigacional que indica la clase base de la llave foránea, 
            // para poder usar el API fluente para eliminación en casacada:    
        public Equipo Equipo {get;set;}
        
    }
}