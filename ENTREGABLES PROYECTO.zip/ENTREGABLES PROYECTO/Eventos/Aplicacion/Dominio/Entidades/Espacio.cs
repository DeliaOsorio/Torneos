using System;
using System.Collections.Generic; //para que pueda usar las listas
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio
{
    public class Espacio
    {
        //Propiedades
        public int Id {get;set;}
        
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(20,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú0-9 ]*", ErrorMessage="Solo se permiten letras y números")]
        public string Nombre {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [MaxLength(20,ErrorMessage="El campo {0} debe ser máximo de {1} caracteres")]
            [MinLength(3,ErrorMessage="El campo {0} debe tener al menos {1} caracteres")]
            [RegularExpression("[A-Za-zá-ú0-9 ]*", ErrorMessage="Solo se permiten letras y números")]
        public string Disciplina {get;set;}

            [Required(ErrorMessage="El campo {0} es obligatorio")]
            //[MaxLength(5,ErrorMessage="El campo {0} debe ser máximo de {1} dígitos")]
            //[MinLength(1,ErrorMessage="El campo {0} debe tener al menos {1} dígito")]
        public int Espectadores {get;set;}

            //Llave foranea para la relación con Escenario
            [Required(ErrorMessage="El campo {0} es obligatorio")]
            [Display(Name="Escenario")] //DataAnnotation para mostrar en la vista un nombre más entendible
        public int EscenarioId {get;set;}

            //Propiedad navigacional para complementar la relacion con Escenario por si se necesita
        public Escenario Escenario {get;set;}    
    }
}